-- phpMyAdmin SQL Dump
-- version 4.2.7.1
-- http://www.phpmyadmin.net
--
-- Host: 127.0.0.1
-- Generation Time: Feb 09, 2017 at 08:08 PM
-- Server version: 5.5.39
-- PHP Version: 5.4.31

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;

--
-- Database: `ydn_db`
--
CREATE DATABASE IF NOT EXISTS `ydn_db` DEFAULT CHARACTER SET latin1 COLLATE latin1_swedish_ci;
USE `ydn_db`;

-- --------------------------------------------------------

--
-- Table structure for table `barang1`
--

DROP TABLE IF EXISTS `barang1`;
CREATE TABLE IF NOT EXISTS `barang1` (
  `idb` varchar(11) NOT NULL,
  `brand` varchar(20) NOT NULL,
  `nama` varchar(40) NOT NULL,
  `jenis` varchar(21) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `barang1`
--

INSERT INTO `barang1` (`idb`, `brand`, `nama`, `jenis`) VALUES
('B1-001', 'DAYMUST', 'BAJU OKE', 'CELANA'),
('B1-002', 'daymust1', 'baju merah', 'CELANA'),
('B1-003', 'daymust', 'baju hitam', 'BAJU'),
('B1-004', 'rvjs', 'baju kucing', 'BAJU');

-- --------------------------------------------------------

--
-- Table structure for table `barang2`
--

DROP TABLE IF EXISTS `barang2`;
CREATE TABLE IF NOT EXISTS `barang2` (
  `idb2` varchar(12) NOT NULL,
  `idb1` varchar(12) NOT NULL,
  `harga` varchar(21) NOT NULL,
  `jumlah` varchar(21) NOT NULL,
  `ukuran` varchar(11) NOT NULL,
  `tanggal` varchar(21) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `barang2`
--

INSERT INTO `barang2` (`idb2`, `idb1`, `harga`, `jumlah`, `ukuran`, `tanggal`) VALUES
('B2-001', 'B1-001', '8000', '12', 'M', '18'),
('B2-002', 'B1-001', '70000', '4', 'M', '17'),
('B2-003', 'B1-002', '75000', '4', 'M', '17');

-- --------------------------------------------------------

--
-- Table structure for table `detiltrs`
--

DROP TABLE IF EXISTS `detiltrs`;
CREATE TABLE IF NOT EXISTS `detiltrs` (
`nomor` int(12) NOT NULL,
  `id_trs` varchar(12) DEFAULT NULL,
  `id_brg` varchar(12) DEFAULT NULL,
  `nm_brg` varchar(30) DEFAULT NULL,
  `jml_brg` varchar(12) DEFAULT NULL,
  `hrg_brg` varchar(12) DEFAULT NULL,
  `disc` varchar(12) DEFAULT NULL,
  `total_trs` varchar(15) DEFAULT '00'
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=49 ;

--
-- Dumping data for table `detiltrs`
--

INSERT INTO `detiltrs` (`nomor`, `id_trs`, `id_brg`, `nm_brg`, `jml_brg`, `hrg_brg`, `disc`, `total_trs`) VALUES
(1, 'TR-001', 'brg', 'Baju Hitam', '1', NULL, '12', '70400.0'),
(2, 'TR-001', 'brg1', 'celana dalam', '1', NULL, '0', '20000.0'),
(3, 'TR-001', 'brg', 'Baju Hitam', '20', NULL, '0', '1600000.0'),
(4, 'TR-002', 'brg', 'Baju Hitam', '1', NULL, '0', '80000.0'),
(5, 'TR-003', 'brg', 'Baju Hitam', '1', NULL, '0', '80000.0'),
(6, 'TR-004', 'brg', 'Baju Hitam', '1', NULL, '0', '80000.0'),
(7, 'TR-005', 'brg', 'Baju Hitam', '1', NULL, '0', '80000.0'),
(8, 'TR-005', 'brg', 'Baju Hitam', '1', NULL, '0', '80000.0'),
(10, 'TR-005', 'brg', 'Baju Hitam', '1', NULL, '0', '80000.0'),
(11, 'TR-005', 'brg', 'Baju Hitam', '1', NULL, '0', '80000.0'),
(12, 'TR-005', 'brg', 'Baju Hitam', '1', NULL, '0', '80000.0'),
(13, 'TR-007', 'brg', 'Baju Hitam', '2', NULL, '0', '160000.0'),
(14, 'TR-007', 'brg', 'Baju Hitam', '1', NULL, '0', '80000.0'),
(16, 'TR-008', 'brg', 'Baju Hitam', '1', NULL, '0', '80000.0'),
(17, 'TR-008', 'brg', 'Baju Hitam', '1', NULL, '0', '80000.0'),
(19, 'TR-009', 'brg', 'Baju Hitam', '1', NULL, '0', '80000.0'),
(20, 'TR-009', 'brg', 'Baju Hitam', '1', NULL, '0', '80000.0'),
(22, 'TR-010', 'brg', 'Baju Hitam', '1', NULL, '0', '80000.0'),
(23, 'TR-011', 'brg', 'Baju Hitam', '1', NULL, '0', '80000.0'),
(24, 'TR-011', 'brg', 'Baju Hitam', '1', NULL, '0', '80000.0'),
(25, 'TR-013', 'brg', 'Baju Hitam', '1', NULL, '0', '80000.0'),
(26, 'TR-013', 'brg', 'Baju Hitam', '1', NULL, '0', '80000.0'),
(28, 'TR-014', 'brg', 'Baju Hitam', '1', NULL, '0', '80000.0'),
(29, 'TR-015', 'brg', 'Baju Hitam', '1', NULL, '0', '80000.0'),
(30, 'TR-016', 'brg', 'Baju Hitam', '1', '80000', '0', '80000.0'),
(31, 'TR-016', 'brg1', 'celana dalam', '1', '20000', '0', '20000.0'),
(32, 'TR-016', 'brg', 'Baju Hitam', '1', '80000', '0', '80000.0'),
(33, 'TR-017', 'brg', 'Baju Hitam', '1', '80000', '0', '80000.0'),
(34, 'TR-017', 'brg', 'Baju Hitam', '1', '80000', '0', '80000.0'),
(36, 'TR-018', 'brg', 'Baju Hitam', '1', '80000', '0', '80000.0'),
(37, 'TR-019', 'brg', 'Baju Hitam', '1', '80000', '0', '80000.0'),
(38, 'TR-019', 'brg', 'Baju Hitam', '1', '80000', '0', '80000.0'),
(39, 'TR-020', 'brg', 'Baju Hitam', '1', '80000', '0', '80000.0'),
(40, 'TR-020', 'brg1', 'celana dalam', '1', '20000', '0', '20000.0'),
(41, 'TR-020', 'brg', 'Baju Hitam', '1', '80000', '0', '80000.0'),
(42, 'TR-021', 'brg', 'Baju Hitam', '1', '80000', '0', '80000.0'),
(43, 'TR-021', 'brg', 'Baju Hitam', '1', '80000', '0', '80000.0'),
(45, 'TR-022', 'brg', 'Baju Hitam', '1', '80000', '0', '80000.0'),
(46, 'TR-023', 'brg', 'Baju Hitam', '1', '80000', '0', '80000.0'),
(47, 'TR-024', 'BR-003', 'KOLOR', '1', '50000', '0', '50000.0'),
(48, 'TR-024', 'BR-002', 'baju lengan panjang', '1', '90000', '20', '72000.0');

-- --------------------------------------------------------

--
-- Table structure for table `detiltrs_temp`
--

DROP TABLE IF EXISTS `detiltrs_temp`;
CREATE TABLE IF NOT EXISTS `detiltrs_temp` (
`nomor` int(12) NOT NULL,
  `id_trs` varchar(12) NOT NULL,
  `id_brg` varchar(12) NOT NULL,
  `brand` varchar(20) NOT NULL,
  `nm_brg` varchar(30) NOT NULL,
  `ukuran` varchar(20) NOT NULL,
  `jml_brg` varchar(12) NOT NULL,
  `hrg_brg` varchar(12) NOT NULL,
  `disc` varchar(12) NOT NULL,
  `total_trs` varchar(15) NOT NULL
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=2 ;

--
-- Dumping data for table `detiltrs_temp`
--

INSERT INTO `detiltrs_temp` (`nomor`, `id_trs`, `id_brg`, `brand`, `nm_brg`, `ukuran`, `jml_brg`, `hrg_brg`, `disc`, `total_trs`) VALUES
(1, 'TR-025', 'B2-002', 'B1-001', 'BAJU OKE', '4', '1', '70000', '0', '70000.0');

-- --------------------------------------------------------

--
-- Table structure for table `tbbarang`
--

DROP TABLE IF EXISTS `tbbarang`;
CREATE TABLE IF NOT EXISTS `tbbarang` (
  `id_brg` varchar(12) NOT NULL,
  `nm_brg` varchar(22) NOT NULL,
  `jenis_brg` varchar(15) NOT NULL,
  `harga_brg` varchar(22) NOT NULL,
  `jumlah_brg` varchar(22) NOT NULL,
  `brand` varchar(19) NOT NULL,
  `tgl_masuk` varchar(15) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `tbbarang`
--

INSERT INTO `tbbarang` (`id_brg`, `nm_brg`, `jenis_brg`, `harga_brg`, `jumlah_brg`, `brand`, `tgl_masuk`) VALUES
('BR-001', 'BAJU HITAM', 'BAJU', '950000', '15', 'DAYMUST', '05-02-2017'),
('BR-002', 'HITAM BERKILAU', 'BAJU', '80000', '15', 'YDN12', '05-02-2017');

-- --------------------------------------------------------

--
-- Table structure for table `tbpengguna`
--

DROP TABLE IF EXISTS `tbpengguna`;
CREATE TABLE IF NOT EXISTS `tbpengguna` (
  `IDPengguna` varchar(11) NOT NULL,
  `nama` varchar(25) NOT NULL,
  `sandi` varchar(10) NOT NULL,
  `jabatan` varchar(10) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `tbpengguna`
--

INSERT INTO `tbpengguna` (`IDPengguna`, `nama`, `sandi`, `jabatan`) VALUES
('p001', 'admin', 'admin', 'admin'),
('p002', 'dimas', 'dimas', 'bawahan');

-- --------------------------------------------------------

--
-- Table structure for table `transaksi`
--

DROP TABLE IF EXISTS `transaksi`;
CREATE TABLE IF NOT EXISTS `transaksi` (
  `id_trs` varchar(22) NOT NULL,
  `tanggal` varchar(15) NOT NULL,
  `kasir` varchar(22) NOT NULL,
  `totalitem` varchar(10) NOT NULL,
  `totalPenjualan` varchar(22) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `transaksi`
--

INSERT INTO `transaksi` (`id_trs`, `tanggal`, `kasir`, `totalitem`, `totalPenjualan`) VALUES
('TR-001', '01-02-2017', 'admin', '22', 'Rp. 1690400'),
('TR-002', '01-02-2017', 'null', '1', 'Rp. 80000'),
('TR-003', '01-02-2017', 'null', '1', 'Rp. 80000'),
('TR-004', '01-02-2017', 'null', '1', 'Rp. 80000'),
('TR-005', '01-02-2017', 'null', '2', 'Rp. 160000'),
('TR-006', '01-02-2017', 'null', '3', 'Rp. 240000'),
('TR-007', '01-02-2017', 'null', '3', 'Rp. 240000'),
('TR-008', '01-02-2017', 'admin', '2', 'Rp. 160000'),
('TR-009', '01-02-2017', 'admin', '2', 'Rp. 160000'),
('TR-010', '01-02-2017', 'null', '1', 'Rp. 80000'),
('TR-011', '01-02-2017', 'null', '1', 'Rp. 80000'),
('TR-012', '01-02-2017', 'null', '1', 'Rp. 80000'),
('TR-013', '01-02-2017', 'null', '2', 'Rp. 160000'),
('TR-014', '01-02-2017', 'null', '1', 'Rp. 80000'),
('TR-015', '01-02-2017', 'null', '1', 'Rp. 80000'),
('TR-016', '01-02-2017', 'admin', '3', 'Rp. 180000'),
('TR-017', '01-02-2017', 'admin', '2', 'Rp. 160000'),
('TR-018', '01-02-2017', 'admin', '1', 'Rp. 80000'),
('TR-019', '01-02-2017', 'admin', '2', 'Rp. 160000'),
('TR-020', '04-02-2017', 'admin', '3', 'Rp. 180000'),
('TR-021', '04-02-2017', 'null', '2', 'Rp. 160000'),
('TR-022', '04-02-2017', 'null', '1', '80000'),
('TR-023', '04-02-2017', 'null', '1', '80000'),
('TR-024', '05-02-2017', 'dimas', '2', '122000');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `barang1`
--
ALTER TABLE `barang1`
 ADD PRIMARY KEY (`idb`);

--
-- Indexes for table `barang2`
--
ALTER TABLE `barang2`
 ADD PRIMARY KEY (`idb2`), ADD KEY `idb1` (`idb1`);

--
-- Indexes for table `detiltrs`
--
ALTER TABLE `detiltrs`
 ADD KEY `nomor` (`nomor`);

--
-- Indexes for table `detiltrs_temp`
--
ALTER TABLE `detiltrs_temp`
 ADD KEY `nomor` (`nomor`);

--
-- Indexes for table `tbbarang`
--
ALTER TABLE `tbbarang`
 ADD PRIMARY KEY (`id_brg`);

--
-- Indexes for table `tbpengguna`
--
ALTER TABLE `tbpengguna`
 ADD PRIMARY KEY (`IDPengguna`);

--
-- Indexes for table `transaksi`
--
ALTER TABLE `transaksi`
 ADD UNIQUE KEY `NoPenjualan_2` (`id_trs`), ADD KEY `NoPenjualan` (`id_trs`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `detiltrs`
--
ALTER TABLE `detiltrs`
MODIFY `nomor` int(12) NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=49;
--
-- AUTO_INCREMENT for table `detiltrs_temp`
--
ALTER TABLE `detiltrs_temp`
MODIFY `nomor` int(12) NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=2;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
