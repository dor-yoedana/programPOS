/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package programpos;

import java.awt.Color;
import java.awt.Component;
import java.awt.event.KeyEvent;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.text.DecimalFormat;
import java.text.DecimalFormatSymbols;
import java.text.NumberFormat;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.Vector;
import javax.swing.JOptionPane;
import javax.swing.JTextField;
import javax.swing.table.DefaultTableModel;
import javax.swing.table.TableColumn;
import javax.swing.table.TableModel;
import java.awt.PrintJob;
import java.awt.Graphics;
import java.awt.Font;

/**
 *
 * @author ydn
 */
public class kasir extends javax.swing.JFrame {
    String nama = usersession.getU_nama();
    /**
     * Creates new form kasir
     */
    public kasir() {
        initComponents();
        setLocationRelativeTo(this);
        tglhari();
        namauser.setText(nama);
        autokode2();
        kodeitem.requestFocus();
        hapustabel();
        tabelmodel();
        lebarkolom();
    }
    public String id2,br,nb,jb,uk,jm,hg;
    public String getid(){
        return id2;
    }
    public String getbr(){
        return br;
    }
    public String getnb(){
        return nb;
    }
    public String getjb(){
        return jb;
    }
    public String getuk(){
        return uk;
    }
    public String getharga(){
        return hg;
    }
    public void itemterpilih(){
        databarang dt = new databarang();
        dt.ks=this;
        kodeitem.setText(id2);
        namaitem.setText(nb);
        ukuran.setText(uk);
        hargaitem.setText(hg);
        jumlah.requestFocus();
        jumlah.setText("1");
        jumlah.selectAll();
        potongan.setText("0");
    }
    public void ambildatabahan(){
        try {
            String sql ="select * from tbbarang where id_brg = '"+kodeitem.getText()+"'";
            ResultSet rs = koneksiDB.executeQuery(sql);
            if (rs.next()) {
                String n = rs.getString(2);
                String h = rs.getString(4);
                namaitem.setText(n);
                hargaitem.setText(h);
                jumlah.setText("1");
                potongan.setText("0");
                jumlah.selectAll();
                jumlah.requestFocus();
            }else{
                JOptionPane.showMessageDialog(this,"Data Tidak ditemukan","DATA",JOptionPane.WARNING_MESSAGE);
                kodeitem.requestFocus();
                kodeitem.setText("");
            }
        } catch (Exception e) {
      }
    }
    public void notabel(){
        int baris = jTable1.getRowCount();
        for(int i=0;i<baris;i++){
        String no = String.valueOf(i+1);
        jTable1.setValueAt(no+".",i,0);
        }
    }
    public void autokode2(){
        try {
            String sql =  "SELECT right(id_trs,2) FROM transaksi";
            String query = "select max(substring(id_trs, 4,5))+1 from transaksi";
            ResultSet qr = koneksiDB.executeQuery(query);
            ResultSet rs = koneksiDB.executeQuery(sql);
            if (rs.first()==false) {
                no_trans.setText("TR-001");
            }else{
                while (qr.next()) {
                    String ambil = qr.getString(1);
                    no_trans.setText(String.format("TR-%03d", Integer.parseInt(ambil))); 
                }  
            }
        } catch (SQLException e) {
        }
    }
    private void tglhari(){
        Date now = new Date();
        SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd");
        String tglH = sdf.format(now);
        tgl.setText(tglH); 
    }
    public void diskon(){
        double total;
        double persent;
        double persents;
        double per = 100;
        
        String p = potongan.getText();
        String h = hargaitem.getText();
        String j = jumlah.getText();
  
        double ptg = Double.parseDouble(p);
        double hrg = Double.parseDouble(h);
        double jml = Double.parseDouble(j);
        
        total = hrg*jml;
        
        persent = total*(ptg/per); 
        
        persents = total - persent;
        
        String st = String.valueOf(persents);
       
        totalitem.setText(st);
    }
    public void simpan(){
        if ("".equals(kodeitem.getText())||"".equals(jumlah.getText())||"".equals(potongan.getText())) {
            JOptionPane.showMessageDialog(rootPane, "DATA BELUM LENGKAP");
            simpan.setEnabled(false);
            kosongkan();
        }else{
                    String sql = "INSERT INTO detiltrs_temp (id_trs,id_brg,brand,nm_brg,ukuran,jml_brg,hrg_brg,disc,total_trs)" + 
                    "values ('"+no_trans.getText()+"','"+kodeitem.getText()+"','"+br+"','"+namaitem.getText()+"','"+uk+"','"+jumlah.getText()+
                    "','"+hargaitem.getText()+"','"+potongan.getText()+"','"+totalitem.getText()+"')";            
                    int Kone = koneksiDB.execute(sql);
                    if (Kone == 1) {
                        lebarkolom();
                        simpan.setEnabled(false);
                        jumlahitem();
                    }
        }
    }
    private void cetak(){
        PrintJob p = getToolkit().getPrintJob(this, "Report", null);
        Graphics g = p.getGraphics();
        g.setFont(new Font("Serif", Font.BOLD,20));
        g.drawString("MD Konveksi", 250, 50);
        g.setFont(new Font("Serif", Font.PLAIN,16));
        g.drawString("Nama Item", 100, 100);
        g.drawString("Qty", 250, 100);
        g.drawString("Harga", 330, 100);
        g.drawString("Total", 430, 100);
        g.drawLine(75, 108, 500, 108);
        g.setFont(new Font("Serif", Font.PLAIN,12));
        int nl = 0;
        int nilai = 125 + (nl*25);
        for (int i = 0 ; i < jTable1.getModel().getRowCount(); i++) {
            g.drawString(jTable1.getModel().getValueAt(i, 3).toString(), 100, nilai);
            //g.drawString(jTable1.getModel().getValueAt(i, 3).toString(), 100, 125 + (i * 25));//nama item
            g.drawString(jTable1.getModel().getValueAt(i, 6).toString(), 250, 125 + (i * 25));//qty
            g.drawString(jTable1.getModel().getValueAt(i, 5).toString(), 330, 125 + (i * 25));//harga
            g.drawString(jTable1.getModel().getValueAt(i, 8).toString(), 430, 125 + (i * 25));//total
            //JOptionPane.showMessageDialog(rootPane, g);
            nilai++;
            //g.drawLine(75, i+(125+50), 500,i+(125+50));//garis
        }
        g.drawLine(75, 600, 500,600);//garis
        g.setFont(new Font("Serif", Font.BOLD,12));
        g.drawString("Sub Total       : "+TOTAL.getText(), 360, nilai);
        g.drawString("Pembayaran    : "+pembayaran.getText(), 360, nilai);
        nilai++;
        p.end();
    }
    private void SimpandetilTransaksi(){
            try {
            String sql = "INSERT INTO `detiltrs` (`id_trs`,`id_brg`,`brand`,`nm_brg`,`ukuran`,`jml_brg`,`hrg_brg`,`disc`,`total_trs`)"
                    + "SELECT `id_trs`,`id_brg`,`brand`,`nm_brg`,`ukuran`,`jml_brg`,`hrg_brg`,`disc`,`total_trs` FROM `detiltrs_temp`";
            int status = koneksiDB.execute(sql);
                if (status == 0) {
                    JOptionPane.showMessageDialog(rootPane, "tidak terhubung");
                }else{
                    hapustabel();
                    tabelmodel();
                    jButton9.setEnabled(false); 
                    kodeitem.requestFocus();
                }
        } catch (Exception e) {
        }    
    }
    private void SimpanTransaksi(){
        try {
            String sql = "insert into transaksi(id_trs,tanggal,kasir,totalitem,totalPenjualan,keterangan)"
                    + "values('"+no_trans.getText()+"','"+tgl.getText()+"','"+namauser.getText()+"','"+jumlah1.getText()+"','"+TotalSemua.getText()+"','"+keterangan.getText()+"')";
            int status = koneksiDB.execute(sql);
            if (status == 1) {
                TotalSemua.setText("");
                pembayaran.setText("");
                TOTAL.setText("");
                Kembalian.setText("");
                btnTambah1.setEnabled(true);
                autokode2();
                kosongkan();
            JOptionPane.showMessageDialog(this,"Transaksi Sukses");
        }
        } catch (Exception e) {
        }
    }
    private void hapustabel(){
        try {
            String sql = "TRUNCATE `detiltrs_temp`";
            int st = koneksiDB.execute(sql);           
        } catch (Exception e) {
        }
    }
    public void kosongkan(){
        kodeitem.setText("");
        namaitem.setText("");
        potongan.setText("");
        hargaitem.setText("");
        totalitem.setText("");
        jumlah.setText("");
        //jumlah1.setText("");
        ukuran.setText("");
        keterangan.setText("");
    }
    public void lebarkolom(){
        TableColumn clm;
        //tbjuml.setAutoResizeMode(javax.swing.JTable.AUTO_RESIZE_OFF);
        clm = 
        jTable1.getColumnModel().getColumn(0);
        clm.setPreferredWidth(30);
        clm = 
        jTable1.getColumnModel().getColumn(1);
        clm.setPreferredWidth(80);
        clm = 
        jTable1.getColumnModel().getColumn(2);
        clm.setPreferredWidth(200);
        clm = 
        jTable1.getColumnModel().getColumn(3);
        clm.setPreferredWidth(200);
        clm = 
        jTable1.getColumnModel().getColumn(4);
        clm.setPreferredWidth(30);
        clm = 
        jTable1.getColumnModel().getColumn(5);
        clm.setPreferredWidth(60);
        clm = 
        jTable1.getColumnModel().getColumn(6);
        clm.setPreferredWidth(30);
        clm = 
        jTable1.getColumnModel().getColumn(7);
        clm.setPreferredWidth(40); 
        clm = 
        jTable1.getColumnModel().getColumn(8);
        clm.setPreferredWidth(100); 
    }    
    public void tabelmodel(){
        String kolom[] = {"No","Kode","Brand","Nama","Uk","Harga","Qty","Disc","Total"};
        DefaultTableModel tb = new DefaultTableModel(null, kolom);
        String SQL = "SELECT * from detiltrs_temp";
        ResultSet rs = koneksiDB.executeQuery(SQL);
        try {
            while (rs.next()) {
                String no = rs.getString(1);
                String kode = rs.getString(3);
                String br = rs.getString(4);
                String nama = rs.getString(5);
                String harga = rs.getString(8);
                String jumlah = rs.getString(7);
                String uk = rs.getString(6);
                String potongan = rs.getString(9);
                String total = rs.getString(10);
                
                String data[] ={no,kode,br,nama,uk,harga,jumlah,potongan,total};
                tb.addRow(data);
            }
        } catch (Exception e) {
        }
        jTable1.setModel(tb); 
        lebarkolom();
    }
    /*public void pilih(){
       int baris = jTable1.getSelectedColumn();
        if (baris != -1) {
            kodeitem.setText(jTable1.getValueAt(baris, 0).toString());
            namaitem.setText(jTable1.getValueAt(baris, 1).toString());
            jumlah.setText(jTable1.getValueAt(baris, 2).toString());
            potongan.setText(jTable1.getValueAt(baris, 3).toString());
            totalitem.setText(jTable1.getValueAt(baris, 4).toString());
        }
    }*/
    public void hapusdata(){
    int baris = jTable1.getSelectedRow();
        if (baris != -1){
            String ID = jTable1.getValueAt(baris, 0).toString();
            String sql = "delete from detiltrs_temp where nomor = '"+ID+"'";
            int status = koneksiDB.execute(sql);
            if (status == 1) {
                JOptionPane.showMessageDialog(this,"data telah di HAPUS","SUKSES",JOptionPane.INFORMATION_MESSAGE);
                tabelmodel();
                jButton3.setEnabled(false);
            }else{
                JOptionPane.showMessageDialog(this, "data gagal di HAPUS", "GAGAL",JOptionPane.ERROR_MESSAGE);
            }
        }
    }
    public void jumlahdata(){
        //menjumlahkan data pada tabel.
        try {
        DecimalFormat kursIndonesia = (DecimalFormat) DecimalFormat.getCurrencyInstance();
        DecimalFormatSymbols formatRp = new DecimalFormatSymbols();
        formatRp.setCurrencySymbol("Rp. ");
        formatRp.setMonetaryDecimalSeparator(',');
        formatRp.setGroupingSeparator('.');
        kursIndonesia.setDecimalFormatSymbols(formatRp);
        
          String sql = "SELECT SUM(`total_trs`) FROM `detiltrs_temp`";
          ResultSet rs = koneksiDB.executeQuery(sql);
            while (rs.next()) {
                String jumlah = rs.getString(1);
                double jm = Double.parseDouble(jumlah);
                TotalSemua.setText(jumlah);
                TOTAL.setText(kursIndonesia.format(jm));
            }
        } catch (Exception e) {
        }
    }
    public void jumlahitem(){
        try {
            String qry = "SELECT SUM(`jml_brg`) FROM `detiltrs_temp`";
            ResultSet Rs =koneksiDB.executeQuery(qry);
            while (Rs.next()) {
                String oke = Rs.getString(1);
                jumlah1.setText(oke);
            }
        } catch (Exception e) {
        }
    }
    public void pembayaran(){
        DecimalFormat kursIndonesia = (DecimalFormat) DecimalFormat.getCurrencyInstance();
        DecimalFormatSymbols formatRp = new DecimalFormatSymbols();
        formatRp.setCurrencySymbol("Rp. ");
        formatRp.setMonetaryDecimalSeparator(',');
        formatRp.setGroupingSeparator('.');
        kursIndonesia.setDecimalFormatSymbols(formatRp);
        
        String T = TotalSemua.getText();
        String P = pembayaran.getText();
        
        double tot = Double.parseDouble(T);
        double Pen = Double.parseDouble(P);
  
        if (Pen >= tot){
            double kemb; 
            kemb = Pen - tot;
            //String k = String.valueOf(kemb);
            Kembalian.setText(kursIndonesia.format(kemb));  
            jButton9.setEnabled(true);
            jButton9.requestFocus();
     }else{
        if (Pen<=tot) {
            JOptionPane.showMessageDialog(rootPane, "Uangnya kurang","PERIKSA NILAI PEMBAYARAN",JOptionPane.WARNING_MESSAGE);
            Kembalian.setText("");
            jButton9.setEnabled(false);
            }
        }
    }
    public void huruf(KeyEvent a){
        if (Character.isAlphabetic(a.getKeyChar())) {
            a.consume();
        }
    }
    /**
     * This method is called from within the constructor to initialize the form.
     * WARNING: Do NOT modify this code. The content of this method is always
     * regenerated by the Form Editor.
     */
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jPanel1 = new javax.swing.JPanel();
        jScrollPane1 = new javax.swing.JScrollPane();
        jTable1 = new javax.swing.JTable();
        jLabel2 = new javax.swing.JLabel();
        jLabel6 = new javax.swing.JLabel();
        jLabel10 = new javax.swing.JLabel();
        jPanel6 = new javax.swing.JPanel();
        jLabel11 = new javax.swing.JLabel();
        TOTAL = new javax.swing.JTextField();
        jLabel12 = new javax.swing.JLabel();
        Kembalian = new javax.swing.JTextField();
        jPanel2 = new javax.swing.JPanel();
        jLabel3 = new javax.swing.JLabel();
        jButton4 = new javax.swing.JButton();
        jButton5 = new javax.swing.JButton();
        jButton7 = new javax.swing.JButton();
        jLabel1 = new javax.swing.JLabel();
        no_trans = new javax.swing.JLabel();
        namauser = new javax.swing.JLabel();
        tgl = new javax.swing.JLabel();
        jPanel5 = new javax.swing.JPanel();
        jLabel7 = new javax.swing.JLabel();
        kodeitem = new javax.swing.JTextField();
        jLabel15 = new javax.swing.JLabel();
        namaitem = new javax.swing.JTextField();
        jumlah = new javax.swing.JTextField();
        jLabel8 = new javax.swing.JLabel();
        potongan = new javax.swing.JTextField();
        jLabel9 = new javax.swing.JLabel();
        simpan = new javax.swing.JButton();
        jLabel16 = new javax.swing.JLabel();
        hargaitem = new javax.swing.JTextField();
        jLabel22 = new javax.swing.JLabel();
        jLabel23 = new javax.swing.JLabel();
        totalitem = new javax.swing.JTextField();
        cari = new javax.swing.JButton();
        ukuran = new javax.swing.JTextField();
        jLabel13 = new javax.swing.JLabel();
        TotalSemua = new javax.swing.JTextField();
        jLabel14 = new javax.swing.JLabel();
        jButton9 = new javax.swing.JButton();
        btnTambah1 = new javax.swing.JButton();
        jButton3 = new javax.swing.JButton();
        jLabel20 = new javax.swing.JLabel();
        pembayaran = new javax.swing.JTextField();
        jScrollPane2 = new javax.swing.JScrollPane();
        keterangan = new javax.swing.JTextPane();
        jLabel19 = new javax.swing.JLabel();
        jumlah1 = new javax.swing.JLabel();

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);
        setUndecorated(true);
        setResizable(false);

        jPanel1.setBackground(new java.awt.Color(255, 255, 255));

        jTable1.setBackground(new java.awt.Color(254, 254, 254));
        jTable1.setFont(new java.awt.Font("SansSerif", 1, 13)); // NOI18N
        jTable1.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {

            },
            new String [] {
                "No", "Id", "Brand", "Nama Item", "Harga", "Jumlah", "Uk", "Disc", "Total"
            }
        ));
        jTable1.setCursor(new java.awt.Cursor(java.awt.Cursor.DEFAULT_CURSOR));
        jTable1.setRowHeight(22);
        jTable1.setUpdateSelectionOnSort(false);
        jTable1.setVerifyInputWhenFocusTarget(false);
        jTable1.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                jTable1MouseClicked(evt);
            }
        });
        jScrollPane1.setViewportView(jTable1);
        if (jTable1.getColumnModel().getColumnCount() > 0) {
            jTable1.getColumnModel().getColumn(0).setMaxWidth(40);
            jTable1.getColumnModel().getColumn(1).setMaxWidth(120);
            jTable1.getColumnModel().getColumn(2).setMaxWidth(200);
            jTable1.getColumnModel().getColumn(3).setMaxWidth(1600);
            jTable1.getColumnModel().getColumn(4).setMaxWidth(800);
            jTable1.getColumnModel().getColumn(5).setMaxWidth(70);
            jTable1.getColumnModel().getColumn(6).setMaxWidth(40);
            jTable1.getColumnModel().getColumn(7).setMaxWidth(60);
            jTable1.getColumnModel().getColumn(8).setMaxWidth(1000);
        }

        jLabel2.setFont(new java.awt.Font("SansSerif", 1, 13)); // NOI18N
        jLabel2.setForeground(new java.awt.Color(116, 94, 94));
        jLabel2.setText("No. Transaksi :");

        jLabel6.setFont(new java.awt.Font("SansSerif", 1, 13)); // NOI18N
        jLabel6.setForeground(new java.awt.Color(116, 94, 94));
        jLabel6.setText("User :");

        jLabel10.setFont(new java.awt.Font("SansSerif", 1, 13)); // NOI18N
        jLabel10.setForeground(new java.awt.Color(116, 94, 94));
        jLabel10.setText("Tgl / Jam :");

        jPanel6.setBackground(new java.awt.Color(254, 254, 254));

        jLabel11.setFont(new java.awt.Font("SansSerif", 1, 14)); // NOI18N
        jLabel11.setForeground(new java.awt.Color(116, 94, 94));
        jLabel11.setText("Total :");

        TOTAL.setFont(new java.awt.Font("SansSerif", 1, 24)); // NOI18N
        TOTAL.setBorder(javax.swing.BorderFactory.createEtchedBorder());
        TOTAL.setFocusable(false);
        TOTAL.setOpaque(false);

        jLabel12.setFont(new java.awt.Font("SansSerif", 1, 14)); // NOI18N
        jLabel12.setForeground(new java.awt.Color(116, 94, 94));
        jLabel12.setText("Kembalian :");

        Kembalian.setBackground(new java.awt.Color(102, 102, 102));
        Kembalian.setFont(new java.awt.Font("Ubuntu", 1, 17)); // NOI18N
        Kembalian.setForeground(new java.awt.Color(255, 255, 255));
        Kembalian.setBorder(javax.swing.BorderFactory.createEtchedBorder());
        Kembalian.setFocusable(false);

        javax.swing.GroupLayout jPanel6Layout = new javax.swing.GroupLayout(jPanel6);
        jPanel6.setLayout(jPanel6Layout);
        jPanel6Layout.setHorizontalGroup(
            jPanel6Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel6Layout.createSequentialGroup()
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addGroup(jPanel6Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(jLabel12, javax.swing.GroupLayout.Alignment.TRAILING)
                    .addComponent(jLabel11, javax.swing.GroupLayout.Alignment.TRAILING))
                .addGap(4, 4, 4)
                .addGroup(jPanel6Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                    .addComponent(Kembalian, javax.swing.GroupLayout.DEFAULT_SIZE, 433, Short.MAX_VALUE)
                    .addComponent(TOTAL))
                .addContainerGap())
        );
        jPanel6Layout.setVerticalGroup(
            jPanel6Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel6Layout.createSequentialGroup()
                .addGroup(jPanel6Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(TOTAL, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(jLabel11, javax.swing.GroupLayout.PREFERRED_SIZE, 27, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(0, 0, 0)
                .addGroup(jPanel6Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel12, javax.swing.GroupLayout.PREFERRED_SIZE, 26, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(Kembalian, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)))
        );

        jPanel2.setBackground(new java.awt.Color(204, 204, 204));

        jLabel3.setFont(new java.awt.Font("Sawasdee", 0, 36)); // NOI18N
        jLabel3.setForeground(new java.awt.Color(254, 254, 254));

        jButton4.setBackground(new java.awt.Color(204, 51, 0));
        jButton4.setFont(new java.awt.Font("Arial Black", 1, 11)); // NOI18N
        jButton4.setForeground(new java.awt.Color(254, 254, 254));
        jButton4.setText("X");
        jButton4.setBorder(javax.swing.BorderFactory.createEmptyBorder(1, 1, 1, 1));
        jButton4.setCursor(new java.awt.Cursor(java.awt.Cursor.HAND_CURSOR));
        jButton4.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton4ActionPerformed(evt);
            }
        });

        jButton5.setBackground(new java.awt.Color(255, 255, 255));
        jButton5.setFont(new java.awt.Font("Arial Black", 1, 11)); // NOI18N
        jButton5.setForeground(new java.awt.Color(51, 51, 0));
        jButton5.setText("--");
        jButton5.setBorder(javax.swing.BorderFactory.createEmptyBorder(1, 1, 1, 1));
        jButton5.setCursor(new java.awt.Cursor(java.awt.Cursor.HAND_CURSOR));
        jButton5.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton5ActionPerformed(evt);
            }
        });

        jButton7.setBackground(new java.awt.Color(255, 255, 255));
        jButton7.setFont(new java.awt.Font("Arial Black", 1, 11)); // NOI18N
        jButton7.setForeground(new java.awt.Color(102, 102, 0));
        jButton7.setText("<");
        jButton7.setBorder(javax.swing.BorderFactory.createEmptyBorder(1, 1, 1, 1));
        jButton7.setCursor(new java.awt.Cursor(java.awt.Cursor.HAND_CURSOR));
        jButton7.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton7ActionPerformed(evt);
            }
        });

        jLabel1.setIcon(new javax.swing.ImageIcon(getClass().getResource("/images/kasir.PNG"))); // NOI18N

        javax.swing.GroupLayout jPanel2Layout = new javax.swing.GroupLayout(jPanel2);
        jPanel2.setLayout(jPanel2Layout);
        jPanel2Layout.setHorizontalGroup(
            jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel2Layout.createSequentialGroup()
                .addGap(56, 56, 56)
                .addComponent(jLabel3)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(jLabel1)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addComponent(jButton7, javax.swing.GroupLayout.PREFERRED_SIZE, 33, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(jButton5, javax.swing.GroupLayout.PREFERRED_SIZE, 33, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(jButton4, javax.swing.GroupLayout.PREFERRED_SIZE, 33, javax.swing.GroupLayout.PREFERRED_SIZE))
        );
        jPanel2Layout.setVerticalGroup(
            jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                .addComponent(jButton4)
                .addComponent(jButton5, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addComponent(jButton7, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel2Layout.createSequentialGroup()
                .addGap(0, 0, Short.MAX_VALUE)
                .addComponent(jLabel3, javax.swing.GroupLayout.PREFERRED_SIZE, 37, javax.swing.GroupLayout.PREFERRED_SIZE))
            .addComponent(jLabel1, javax.swing.GroupLayout.DEFAULT_SIZE, 69, Short.MAX_VALUE)
        );

        no_trans.setFont(new java.awt.Font("SansSerif", 1, 13)); // NOI18N
        no_trans.setForeground(new java.awt.Color(116, 94, 94));
        no_trans.setText("No Transaksi");

        namauser.setFont(new java.awt.Font("SansSerif", 1, 13)); // NOI18N
        namauser.setForeground(new java.awt.Color(116, 94, 94));
        namauser.setText("User");

        tgl.setFont(new java.awt.Font("SansSerif", 1, 13)); // NOI18N
        tgl.setForeground(new java.awt.Color(116, 94, 94));
        tgl.setText("Tgl / Jam");

        jPanel5.setBackground(new java.awt.Color(204, 255, 204));
        jPanel5.setBorder(javax.swing.BorderFactory.createEtchedBorder(new java.awt.Color(255, 204, 204), null));

        jLabel7.setFont(new java.awt.Font("SansSerif", 1, 13)); // NOI18N
        jLabel7.setForeground(new java.awt.Color(116, 94, 94));
        jLabel7.setText("Id :");

        kodeitem.setBackground(new java.awt.Color(254, 254, 254));
        kodeitem.setFont(new java.awt.Font("SansSerif", 1, 13)); // NOI18N
        kodeitem.setForeground(new java.awt.Color(116, 94, 94));
        kodeitem.setBorder(javax.swing.BorderFactory.createEtchedBorder());
        kodeitem.setFocusable(false);
        kodeitem.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                kodeitemActionPerformed(evt);
            }
        });

        jLabel15.setFont(new java.awt.Font("SansSerif", 1, 13)); // NOI18N
        jLabel15.setForeground(new java.awt.Color(116, 94, 94));
        jLabel15.setText("Nama :");

        namaitem.setBackground(new java.awt.Color(254, 254, 254));
        namaitem.setFont(new java.awt.Font("SansSerif", 1, 13)); // NOI18N
        namaitem.setForeground(new java.awt.Color(116, 94, 94));
        namaitem.setBorder(javax.swing.BorderFactory.createEtchedBorder());
        namaitem.setFocusable(false);

        jumlah.setBackground(new java.awt.Color(254, 254, 254));
        jumlah.setFont(new java.awt.Font("SansSerif", 1, 13)); // NOI18N
        jumlah.setForeground(new java.awt.Color(116, 94, 94));
        jumlah.setBorder(javax.swing.BorderFactory.createEtchedBorder());
        jumlah.setCursor(new java.awt.Cursor(java.awt.Cursor.TEXT_CURSOR));
        jumlah.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jumlahActionPerformed(evt);
            }
        });
        jumlah.addKeyListener(new java.awt.event.KeyAdapter() {
            public void keyTyped(java.awt.event.KeyEvent evt) {
                jumlahKeyTyped(evt);
            }
        });

        jLabel8.setFont(new java.awt.Font("SansSerif", 1, 13)); // NOI18N
        jLabel8.setForeground(new java.awt.Color(116, 94, 94));
        jLabel8.setText("Qty :");

        potongan.setBackground(new java.awt.Color(254, 254, 254));
        potongan.setFont(new java.awt.Font("SansSerif", 1, 13)); // NOI18N
        potongan.setForeground(new java.awt.Color(116, 94, 94));
        potongan.setBorder(javax.swing.BorderFactory.createEtchedBorder());
        potongan.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                potonganActionPerformed(evt);
            }
        });
        potongan.addKeyListener(new java.awt.event.KeyAdapter() {
            public void keyTyped(java.awt.event.KeyEvent evt) {
                potonganKeyTyped(evt);
            }
        });

        jLabel9.setFont(new java.awt.Font("SansSerif", 1, 13)); // NOI18N
        jLabel9.setForeground(new java.awt.Color(116, 94, 94));
        jLabel9.setText("Disc :");

        simpan.setBackground(new java.awt.Color(0, 0, 0));
        simpan.setFont(new java.awt.Font("Calibri", 0, 12)); // NOI18N
        simpan.setForeground(new java.awt.Color(204, 204, 204));
        simpan.setText("Input");
        simpan.setBorder(javax.swing.BorderFactory.createEmptyBorder(1, 1, 1, 1));
        simpan.setBorderPainted(false);
        simpan.setCursor(new java.awt.Cursor(java.awt.Cursor.HAND_CURSOR));
        simpan.setEnabled(false);
        simpan.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                simpanActionPerformed(evt);
            }
        });
        simpan.addKeyListener(new java.awt.event.KeyAdapter() {
            public void keyPressed(java.awt.event.KeyEvent evt) {
                simpanKeyPressed(evt);
            }
        });

        jLabel16.setFont(new java.awt.Font("SansSerif", 1, 13)); // NOI18N
        jLabel16.setForeground(new java.awt.Color(116, 94, 94));
        jLabel16.setText("%");

        hargaitem.setBackground(new java.awt.Color(254, 254, 254));
        hargaitem.setFont(new java.awt.Font("SansSerif", 1, 13)); // NOI18N
        hargaitem.setForeground(new java.awt.Color(116, 94, 94));
        hargaitem.setBorder(javax.swing.BorderFactory.createEtchedBorder());
        hargaitem.setFocusable(false);

        jLabel22.setFont(new java.awt.Font("SansSerif", 1, 13)); // NOI18N
        jLabel22.setForeground(new java.awt.Color(116, 94, 94));
        jLabel22.setText("Harga :");

        jLabel23.setFont(new java.awt.Font("SansSerif", 1, 13)); // NOI18N
        jLabel23.setForeground(new java.awt.Color(116, 94, 94));
        jLabel23.setText("Total :");

        totalitem.setBackground(new java.awt.Color(254, 254, 254));
        totalitem.setFont(new java.awt.Font("SansSerif", 1, 13)); // NOI18N
        totalitem.setForeground(new java.awt.Color(116, 94, 94));
        totalitem.setBorder(javax.swing.BorderFactory.createEtchedBorder());
        totalitem.setFocusable(false);

        cari.setBackground(new java.awt.Color(0, 0, 0));
        cari.setFont(new java.awt.Font("Calibri", 0, 12)); // NOI18N
        cari.setForeground(new java.awt.Color(204, 204, 204));
        cari.setText("....");
        cari.setBorder(javax.swing.BorderFactory.createEmptyBorder(1, 1, 1, 1));
        cari.setBorderPainted(false);
        cari.setCursor(new java.awt.Cursor(java.awt.Cursor.HAND_CURSOR));
        cari.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                cariActionPerformed(evt);
            }
        });

        ukuran.setBackground(new java.awt.Color(254, 254, 254));
        ukuran.setFont(new java.awt.Font("SansSerif", 1, 13)); // NOI18N
        ukuran.setForeground(new java.awt.Color(116, 94, 94));
        ukuran.setBorder(javax.swing.BorderFactory.createEtchedBorder());
        ukuran.setFocusable(false);

        javax.swing.GroupLayout jPanel5Layout = new javax.swing.GroupLayout(jPanel5);
        jPanel5.setLayout(jPanel5Layout);
        jPanel5Layout.setHorizontalGroup(
            jPanel5Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel5Layout.createSequentialGroup()
                .addContainerGap()
                .addComponent(jLabel7)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(kodeitem, javax.swing.GroupLayout.PREFERRED_SIZE, 52, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(cari, javax.swing.GroupLayout.PREFERRED_SIZE, 24, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addComponent(jLabel15)
                .addGap(1, 1, 1)
                .addComponent(namaitem, javax.swing.GroupLayout.PREFERRED_SIZE, 96, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(ukuran, javax.swing.GroupLayout.PREFERRED_SIZE, 28, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(28, 28, 28)
                .addComponent(jLabel22)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(hargaitem, javax.swing.GroupLayout.PREFERRED_SIZE, 71, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(jLabel8)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(jumlah, javax.swing.GroupLayout.PREFERRED_SIZE, 26, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(jLabel9)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(potongan, javax.swing.GroupLayout.PREFERRED_SIZE, 31, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(3, 3, 3)
                .addComponent(jLabel16)
                .addGap(8, 8, 8)
                .addComponent(jLabel23)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(totalitem, javax.swing.GroupLayout.PREFERRED_SIZE, 71, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(simpan, javax.swing.GroupLayout.PREFERRED_SIZE, 46, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap())
        );
        jPanel5Layout.setVerticalGroup(
            jPanel5Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel5Layout.createSequentialGroup()
                .addContainerGap()
                .addGroup(jPanel5Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.CENTER)
                    .addComponent(simpan, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                    .addComponent(totalitem, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(jLabel23)
                    .addComponent(potongan, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(jLabel16)
                    .addComponent(jLabel9)
                    .addComponent(jLabel8)
                    .addComponent(jumlah, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(hargaitem, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(jLabel22)
                    .addComponent(namaitem, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(jLabel15)
                    .addComponent(kodeitem, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(jLabel7)
                    .addComponent(cari, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                    .addComponent(ukuran, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addContainerGap())
        );

        jLabel13.setFont(new java.awt.Font("SansSerif", 1, 13)); // NOI18N
        jLabel13.setForeground(new java.awt.Color(116, 94, 94));
        jLabel13.setText("Total Qty :");

        TotalSemua.setBackground(new java.awt.Color(254, 254, 254));
        TotalSemua.setFont(new java.awt.Font("SansSerif", 1, 13)); // NOI18N
        TotalSemua.setForeground(new java.awt.Color(116, 94, 94));
        TotalSemua.setBorder(javax.swing.BorderFactory.createEtchedBorder());
        TotalSemua.setFocusable(false);

        jLabel14.setFont(new java.awt.Font("SansSerif", 1, 13)); // NOI18N
        jLabel14.setForeground(new java.awt.Color(116, 94, 94));
        jLabel14.setText("Total :");

        jButton9.setBackground(new java.awt.Color(1, 1, 1));
        jButton9.setFont(new java.awt.Font("SansSerif", 1, 11)); // NOI18N
        jButton9.setForeground(new java.awt.Color(254, 254, 254));
        jButton9.setText("Bayar");
        jButton9.setBorder(javax.swing.BorderFactory.createEmptyBorder(1, 1, 1, 1));
        jButton9.setCursor(new java.awt.Cursor(java.awt.Cursor.HAND_CURSOR));
        jButton9.setEnabled(false);
        jButton9.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton9ActionPerformed(evt);
            }
        });
        jButton9.addKeyListener(new java.awt.event.KeyAdapter() {
            public void keyPressed(java.awt.event.KeyEvent evt) {
                jButton9KeyPressed(evt);
            }
        });

        btnTambah1.setBackground(new java.awt.Color(1, 1, 1));
        btnTambah1.setFont(new java.awt.Font("SansSerif", 1, 11)); // NOI18N
        btnTambah1.setForeground(new java.awt.Color(254, 254, 254));
        btnTambah1.setText("Cetak");
        btnTambah1.setBorder(javax.swing.BorderFactory.createEmptyBorder(1, 1, 1, 1));
        btnTambah1.setCursor(new java.awt.Cursor(java.awt.Cursor.HAND_CURSOR));
        btnTambah1.setFocusable(false);
        btnTambah1.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnTambah1ActionPerformed(evt);
            }
        });

        jButton3.setBackground(new java.awt.Color(255, 51, 51));
        jButton3.setFont(new java.awt.Font("SansSerif", 1, 11)); // NOI18N
        jButton3.setForeground(new java.awt.Color(254, 254, 254));
        jButton3.setText("Hapus");
        jButton3.setBorder(javax.swing.BorderFactory.createEmptyBorder(1, 1, 1, 1));
        jButton3.setCursor(new java.awt.Cursor(java.awt.Cursor.HAND_CURSOR));
        jButton3.setEnabled(false);
        jButton3.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton3ActionPerformed(evt);
            }
        });

        jLabel20.setFont(new java.awt.Font("SansSerif", 1, 13)); // NOI18N
        jLabel20.setForeground(new java.awt.Color(116, 94, 94));
        jLabel20.setText("Pembayaran :");

        pembayaran.setBackground(new java.awt.Color(254, 254, 254));
        pembayaran.setFont(new java.awt.Font("SansSerif", 1, 13)); // NOI18N
        pembayaran.setForeground(new java.awt.Color(116, 94, 94));
        pembayaran.setBorder(javax.swing.BorderFactory.createEtchedBorder());
        pembayaran.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                pembayaranActionPerformed(evt);
            }
        });

        jScrollPane2.setViewportView(keterangan);

        jLabel19.setText("Keterangan :");

        jumlah1.setFont(new java.awt.Font("SansSerif", 1, 13)); // NOI18N
        jumlah1.setForeground(new java.awt.Color(116, 94, 94));
        jumlah1.setText("qty");

        javax.swing.GroupLayout jPanel1Layout = new javax.swing.GroupLayout(jPanel1);
        jPanel1.setLayout(jPanel1Layout);
        jPanel1Layout.setHorizontalGroup(
            jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(jPanel2, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel1Layout.createSequentialGroup()
                .addGap(0, 0, Short.MAX_VALUE)
                .addComponent(jPanel6, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
            .addGroup(jPanel1Layout.createSequentialGroup()
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                    .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                        .addGroup(jPanel1Layout.createSequentialGroup()
                            .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                .addComponent(jLabel10, javax.swing.GroupLayout.Alignment.TRAILING)
                                .addComponent(jLabel6, javax.swing.GroupLayout.Alignment.TRAILING)
                                .addComponent(jLabel2, javax.swing.GroupLayout.Alignment.TRAILING))
                            .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                            .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                .addComponent(no_trans)
                                .addComponent(namauser)
                                .addComponent(tgl)))
                        .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING, false)
                            .addComponent(jScrollPane1)
                            .addComponent(jPanel5, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)))
                    .addGroup(jPanel1Layout.createSequentialGroup()
                        .addComponent(jButton3, javax.swing.GroupLayout.PREFERRED_SIZE, 115, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGap(71, 71, 71)
                        .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addGroup(jPanel1Layout.createSequentialGroup()
                                .addComponent(jLabel19)
                                .addGap(89, 89, 89)
                                .addComponent(jLabel13)
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                .addComponent(jumlah1))
                            .addComponent(jScrollPane2, javax.swing.GroupLayout.PREFERRED_SIZE, 275, javax.swing.GroupLayout.PREFERRED_SIZE))
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                        .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                            .addGroup(jPanel1Layout.createSequentialGroup()
                                .addGap(47, 47, 47)
                                .addComponent(jLabel14)
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                                .addComponent(TotalSemua, javax.swing.GroupLayout.PREFERRED_SIZE, 147, javax.swing.GroupLayout.PREFERRED_SIZE))
                            .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel1Layout.createSequentialGroup()
                                    .addComponent(jLabel20)
                                    .addGap(16, 16, 16)
                                    .addComponent(pembayaran, javax.swing.GroupLayout.PREFERRED_SIZE, 147, javax.swing.GroupLayout.PREFERRED_SIZE))
                                .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel1Layout.createSequentialGroup()
                                    .addComponent(btnTambah1, javax.swing.GroupLayout.PREFERRED_SIZE, 115, javax.swing.GroupLayout.PREFERRED_SIZE)
                                    .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                    .addComponent(jButton9, javax.swing.GroupLayout.PREFERRED_SIZE, 115, javax.swing.GroupLayout.PREFERRED_SIZE))))))
                .addContainerGap())
        );
        jPanel1Layout.setVerticalGroup(
            jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel1Layout.createSequentialGroup()
                .addComponent(jPanel2, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(jPanel1Layout.createSequentialGroup()
                        .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(jLabel2)
                            .addComponent(no_trans))
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(jLabel6)
                            .addComponent(namauser))
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(jLabel10)
                            .addComponent(tgl)))
                    .addComponent(jPanel6, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addComponent(jPanel5, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(jScrollPane1, javax.swing.GroupLayout.PREFERRED_SIZE, 161, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                        .addComponent(jButton3, javax.swing.GroupLayout.PREFERRED_SIZE, 31, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGroup(jPanel1Layout.createSequentialGroup()
                            .addGap(17, 17, 17)
                            .addComponent(jLabel19)
                            .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                            .addComponent(jScrollPane2, javax.swing.GroupLayout.PREFERRED_SIZE, 60, javax.swing.GroupLayout.PREFERRED_SIZE)))
                    .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                        .addComponent(jLabel13)
                        .addComponent(jumlah1))
                    .addGroup(jPanel1Layout.createSequentialGroup()
                        .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(jLabel14)
                            .addComponent(TotalSemua, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(jLabel20)
                            .addComponent(pembayaran, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                        .addGap(18, 18, 18)
                        .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(jButton9, javax.swing.GroupLayout.PREFERRED_SIZE, 31, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(btnTambah1, javax.swing.GroupLayout.PREFERRED_SIZE, 31, javax.swing.GroupLayout.PREFERRED_SIZE))))
                .addContainerGap())
        );

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addComponent(jPanel1, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(0, 0, Short.MAX_VALUE))
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(jPanel1, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
        );

        pack();
    }// </editor-fold>//GEN-END:initComponents

    private void jButton3ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton3ActionPerformed
        // TODO add your handling code here:
        hapusdata();
        jumlahdata();
        jumlahitem();
    }//GEN-LAST:event_jButton3ActionPerformed

    private void simpanActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_simpanActionPerformed
        // TODO add your handling code here:
            simpan();
            tabelmodel();
            jumlahdata();
            kosongkan();
    }//GEN-LAST:event_simpanActionPerformed

    private void btnTambah1ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnTambah1ActionPerformed
        // TODO add your handling code here:F       
        cetak();
    }//GEN-LAST:event_btnTambah1ActionPerformed

    private void kodeitemActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_kodeitemActionPerformed
        // TODO add your handling code here:
       // ambildatabahan();
        diskon();
    }//GEN-LAST:event_kodeitemActionPerformed

    private void potonganActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_potonganActionPerformed
        // TODO add your handling code here:
        diskon();
        simpan.setEnabled(true);
        simpan.requestFocus();
    }//GEN-LAST:event_potonganActionPerformed

    private void jumlahActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jumlahActionPerformed
        // TODO add your handling code here:
        potongan.requestFocus();
        potongan.selectAll();
        diskon();
    }//GEN-LAST:event_jumlahActionPerformed

    private void jButton4ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton4ActionPerformed
        // TODO add your handling code here:
        System.exit(0);
    }//GEN-LAST:event_jButton4ActionPerformed

    private void jButton5ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton5ActionPerformed
        // TODO add your handling code here:
        setState(ICONIFIED);
    }//GEN-LAST:event_jButton5ActionPerformed

    private void jButton7ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton7ActionPerformed
        // TODO add your handling code here:
        new MenuUtama().show();
        this.dispose();
    }//GEN-LAST:event_jButton7ActionPerformed

    private void pembayaranActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_pembayaranActionPerformed
        // TODO add your handling code here:
        pembayaran();
        Kembalian.setBackground(Color.red);
    }//GEN-LAST:event_pembayaranActionPerformed

    private void jButton9KeyPressed(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_jButton9KeyPressed
        // simpan data transaksi
        SimpandetilTransaksi();
        SimpanTransaksi();
    }//GEN-LAST:event_jButton9KeyPressed

    private void simpanKeyPressed(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_simpanKeyPressed
        // TODO add your handling code here:
            simpan();
            tabelmodel();
            jumlahdata();
            jumlahitem();
            kosongkan();
    }//GEN-LAST:event_simpanKeyPressed

    private void jButton9ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton9ActionPerformed
        // TODO add your handling code here:
            pembayaran();
            SimpandetilTransaksi();
            SimpanTransaksi();
            hapustabel();
            tabelmodel();
    }//GEN-LAST:event_jButton9ActionPerformed

    private void jTable1MouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_jTable1MouseClicked
        // TODO add your handling code here:
        jButton3.setEnabled(true);
    }//GEN-LAST:event_jTable1MouseClicked

    private void cariActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_cariActionPerformed
        // TODO add your handling code here:
        databarang db = new databarang();
        db.ks = this;
        db.setVisible(true);
        jButton9.setEnabled(false);
    }//GEN-LAST:event_cariActionPerformed

    private void jumlahKeyTyped(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_jumlahKeyTyped
        // TODO add your handling code here:
        huruf(evt);
    }//GEN-LAST:event_jumlahKeyTyped

    private void potonganKeyTyped(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_potonganKeyTyped
        // TODO add your handling code here:
        huruf(evt);
    }//GEN-LAST:event_potonganKeyTyped

    /**
     * @param args the command line arguments
     */
    public static void main(String args[]) {
        /* Set the Nimbus look and feel */
        //<editor-fold defaultstate="collapsed" desc=" Look and feel setting code (optional) ">
        /* If Nimbus (introduced in Java SE 6) is not available, stay with the default look and feel.
         * For details see http://download.oracle.com/javase/tutorial/uiswing/lookandfeel/plaf.html 
         */
        try {
            for (javax.swing.UIManager.LookAndFeelInfo info : javax.swing.UIManager.getInstalledLookAndFeels()) {
                if ("Nimbus".equals(info.getName())) {
                    javax.swing.UIManager.setLookAndFeel(info.getClassName());
                    break;
                }
            }
        } catch (ClassNotFoundException ex) {
            java.util.logging.Logger.getLogger(kasir.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (InstantiationException ex) {
            java.util.logging.Logger.getLogger(kasir.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (IllegalAccessException ex) {
            java.util.logging.Logger.getLogger(kasir.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (javax.swing.UnsupportedLookAndFeelException ex) {
            java.util.logging.Logger.getLogger(kasir.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        }
        //</editor-fold>

        /* Create and display the form */
        java.awt.EventQueue.invokeLater(new Runnable() {
            public void run() {
                new kasir().setVisible(true);
            }
        });
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JTextField Kembalian;
    private javax.swing.JTextField TOTAL;
    private javax.swing.JTextField TotalSemua;
    private javax.swing.JButton btnTambah1;
    private javax.swing.JButton cari;
    private javax.swing.JTextField hargaitem;
    private javax.swing.JButton jButton3;
    private javax.swing.JButton jButton4;
    private javax.swing.JButton jButton5;
    private javax.swing.JButton jButton7;
    private javax.swing.JButton jButton9;
    private javax.swing.JLabel jLabel1;
    private javax.swing.JLabel jLabel10;
    private javax.swing.JLabel jLabel11;
    private javax.swing.JLabel jLabel12;
    private javax.swing.JLabel jLabel13;
    private javax.swing.JLabel jLabel14;
    private javax.swing.JLabel jLabel15;
    private javax.swing.JLabel jLabel16;
    private javax.swing.JLabel jLabel19;
    private javax.swing.JLabel jLabel2;
    private javax.swing.JLabel jLabel20;
    private javax.swing.JLabel jLabel22;
    private javax.swing.JLabel jLabel23;
    private javax.swing.JLabel jLabel3;
    private javax.swing.JLabel jLabel6;
    private javax.swing.JLabel jLabel7;
    private javax.swing.JLabel jLabel8;
    private javax.swing.JLabel jLabel9;
    private javax.swing.JPanel jPanel1;
    private javax.swing.JPanel jPanel2;
    private javax.swing.JPanel jPanel5;
    private javax.swing.JPanel jPanel6;
    private javax.swing.JScrollPane jScrollPane1;
    private javax.swing.JScrollPane jScrollPane2;
    private javax.swing.JTable jTable1;
    private javax.swing.JTextField jumlah;
    private javax.swing.JLabel jumlah1;
    private javax.swing.JTextPane keterangan;
    private javax.swing.JTextField kodeitem;
    private javax.swing.JTextField namaitem;
    private javax.swing.JLabel namauser;
    private javax.swing.JLabel no_trans;
    private javax.swing.JTextField pembayaran;
    private javax.swing.JTextField potongan;
    private javax.swing.JButton simpan;
    private javax.swing.JLabel tgl;
    private javax.swing.JTextField totalitem;
    private javax.swing.JTextField ukuran;
    // End of variables declaration//GEN-END:variables
}
