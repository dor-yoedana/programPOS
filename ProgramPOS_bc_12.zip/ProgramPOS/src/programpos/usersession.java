/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package programpos;

/**
 *
 * @author ydn
 */
class usersession {
private static String u_id_pengguna;
    private static String u_nama;
    private static String u_sandi;
    private static String u_jabatan;
    
    public static String getU_id_pengguna(){
        return u_id_pengguna;
    }
    public static void setU_id_pengguna(String u_id_pengguna){
        usersession.u_id_pengguna = u_id_pengguna;
    }
    
    public static String getU_nama(){
        return u_nama;
    }
    public static void setU_nama(String u_nama){
        usersession.u_nama = u_nama;
    }
    
    public static String getU_sandi(){
        return u_sandi;
    }
    public static void setU_sandi(String u_sandi){
        usersession.u_sandi = u_sandi;
    }
    
    public static String getU_jabatan(){
        return u_jabatan;
    }
    public static void setU_jabatan(String u_jabatan){
        usersession.u_jabatan = u_jabatan;
    }
}
