/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package programpos;

import java.sql.ResultSet;
import java.text.DecimalFormat;
import java.text.DecimalFormatSymbols;
import java.text.SimpleDateFormat;
import java.util.Date;
import javax.swing.JOptionPane;
import javax.swing.table.DefaultTableModel;
import javax.swing.table.TableColumn;

/**
 *
 * @author YDN
 */
public class laporandata extends javax.swing.JFrame {
        DecimalFormat kursIndonesia = (DecimalFormat) DecimalFormat.getCurrencyInstance();
        DecimalFormatSymbols formatRp = new DecimalFormatSymbols();
    /**
     * Creates new form laporandata
     */
    public laporandata() {
        initComponents();
        setLocationRelativeTo(this);
        //tableview();
        tanggal();      
    }
    void databrand(){
        String tahun = (String) thn.getSelectedItem();
        String bulan = (String) bln.getSelectedItem();
        String hari = (String) tgl.getSelectedItem();
        String tahun2 = (String) thn1.getSelectedItem();
        String bulan2 = (String) bln1.getSelectedItem();
        String hari2 = (String) tgl1.getSelectedItem();
        String dari = (tahun+'-'+bulan+'-'+hari);
        String ke = (tahun2+'-'+bulan2+'-'+hari2);
        
        String kolom[] = {"Transaki","Brand","Nama","Tanggal","S","M","L","XL","XXL","TOTAL"};
        DefaultTableModel tb = new DefaultTableModel(null, kolom);
        String sql = "SELECT id_trs,brand,`nm_brg`, tanggal,\n" +
                    "SUM(IF( ukuran = 'S', jml_brg, 0)) AS S,\n" +
                    "SUM(IF( ukuran = 'M', jml_brg, 0)) AS M,\n" +
                    "SUM(IF( ukuran = 'L', jml_brg, 0)) AS L,\n" +
                    "SUM(IF( ukuran = 'XL', jml_brg, 0)) AS XL,\n" +
                    "SUM(IF( ukuran = 'XXL', jml_brg, 0)) AS XXL,\n" +
                    "SUM(jml_brg) AS TOTAL\n" +
                    "FROM detiltrs\n" +
                    "LEFT JOIN transaksi USING (`id_trs`)\n" +
                    "WHERE tanggal\n" +
                    "BETWEEN\n" +
                    "'"+dari+"'\n" +
                    "AND \n" +
                    "'"+ke+"'\n" +
                    "GROUP BY nm_brg, id_trs\n" +
                    "ORDER BY brand ASC";
        
        ResultSet rs = koneksiDB.executeQuery(sql);
        try {
            while (rs.next()) {
                String tr = rs.getString(1);
                String br = rs.getString(2);
                String nm = rs.getString(3);
                String tg = rs.getString(4);
                String us = rs.getString(5);
                String um = rs.getString(6);
                String ul = rs.getString(7);
                String xl = rs.getString(8);
                String xxl = rs.getString(9);
                String tt = rs.getString(10);
                
                String data[] = {tr,br,nm,tg,us,um,ul,xl,xxl,tt};
                tb.addRow(data);
            }
        } catch (Exception e) {
        }tabel.setModel(tb); lebarkolom2();
    }
    public void lebarkolom2(){
        TableColumn  cl;       
        cl = 
        tabel.getColumnModel().getColumn(0);
        cl.setPreferredWidth(100);
        cl = 
        tabel.getColumnModel().getColumn(1);
        cl.setPreferredWidth(100);        
        cl = 
        tabel.getColumnModel().getColumn(2);
        cl.setPreferredWidth(200);
        cl = 
        tabel.getColumnModel().getColumn(3);
        cl.setPreferredWidth(100);
        cl = 
        tabel.getColumnModel().getColumn(4);
        cl.setPreferredWidth(50);
        cl = 
        tabel.getColumnModel().getColumn(5);
        cl.setPreferredWidth(50);
        cl = 
        tabel.getColumnModel().getColumn(6);
        cl.setPreferredWidth(50); 
        cl = 
        tabel.getColumnModel().getColumn(7);
        cl.setPreferredWidth(50); 
        cl = 
        tabel.getColumnModel().getColumn(8);
        cl.setPreferredWidth(50); 
        cl = 
        tabel.getColumnModel().getColumn(9);
        cl.setPreferredWidth(80); 
    }    
    void tanggal(){
    Date now = new Date();
    SimpleDateFormat df = new SimpleDateFormat("yyyy");
    String tgl = df.format(now);
    int tg = Integer.parseInt(tgl);
    int tb = tg+1;
        for (int i = 0; i <= 5; i++) {        
    //System.out.println(tb);       
            tb--;
            String gl = String.valueOf(tb);
            thn.addItem(gl);
            thn1.addItem(gl);
        }
    }
    public void lebarkolom(){
        TableColumn  cl;       
        cl = 
        tabel.getColumnModel().getColumn(0);
        cl.setPreferredWidth(50);
        cl = 
        tabel.getColumnModel().getColumn(1);
        cl.setPreferredWidth(30);        
        cl = 
        tabel.getColumnModel().getColumn(2);
        cl.setPreferredWidth(10);
        cl = 
        tabel.getColumnModel().getColumn(3);
        cl.setPreferredWidth(5);
        cl = 
        tabel.getColumnModel().getColumn(4);
        cl.setPreferredWidth(80);
        cl = 
        tabel.getColumnModel().getColumn(5);
        cl.setPreferredWidth(200);    
    }
    public void penjumlahan(){
        formatRp.setCurrencySymbol("Rp. ");
        formatRp.setMonetaryDecimalSeparator(',');
        formatRp.setGroupingSeparator('.');
        kursIndonesia.setDecimalFormatSymbols(formatRp);
        
        String tahun = (String) thn.getSelectedItem();
        String bulan = (String) bln.getSelectedItem();
        String hari = (String) tgl.getSelectedItem();
        String tahun2 = (String) thn1.getSelectedItem();
        String bulan2 = (String) bln1.getSelectedItem();
        String hari2 = (String) tgl1.getSelectedItem();
        String dari = (tahun+'-'+bulan+'-'+hari);
        String ke = (tahun2+'-'+bulan2+'-'+hari2);
        /*String sql = "select sum(totalPenjumlahan) from transaksi where tanggal between"
                + "'"+dari+"' and '"+ke+"'";
        ResultSet rs = koneksiDB.executeQuery(sql);*/       
        try {
        
                String sql = "SELECT SUM(`totalPenjualan`)as total FROM transaksi\n" +
                            "WHERE tanggal BETWEEN\n" +
                            "'"+dari+"'AND'"+ke+"'";
                ResultSet rs = koneksiDB.executeQuery(sql);               
                while (rs.next()) {
                String ok = rs.getString("total");            
                double nl = Double.parseDouble(ok);
                total.setText(kursIndonesia.format(nl));
            }
        } catch (Exception e) {
        }
    }
    public void tableview(String sql){
        String kolom[] = {"Transaksi","Tanggal","Kasir","T.Qty","T.Penjualan","Keterangan"};
        DefaultTableModel tb = new DefaultTableModel(null, kolom);
        
        ResultSet rs = koneksiDB.executeQuery(sql);
        try {
            while(rs.next()){
                String id = rs.getString(1);
                String tg = rs.getString(2);
                String ks = rs.getString(3);
                String tm = rs.getString(4);
                String tp = rs.getString(5);
                String kt = rs.getString(6);
                //String totalok = rs.getString("sum(totalPenjualan)");
                
                String data[] = {id,tg,ks,tm,tp,kt};
                tb.addRow(data);
                //total.setText(totalok);
            }                   
        } catch (Exception e) {
        }tabel.setModel(tb);
        lebarkolom();
    }
    /**
     * This method is called from within the constructor to initialize the form.
     * WARNING: Do NOT modify this code. The content of this method is always
     * regenerated by the Form Editor.
     */
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        frame = new javax.swing.JPanel();
        jScrollPane1 = new javax.swing.JScrollPane();
        tabel = new javax.swing.JTable();
        jButton7 = new javax.swing.JButton();
        jButton5 = new javax.swing.JButton();
        jButton4 = new javax.swing.JButton();
        jPanel2 = new javax.swing.JPanel();
        jLabel1 = new javax.swing.JLabel();
        tgl = new javax.swing.JComboBox();
        bln = new javax.swing.JComboBox();
        thn = new javax.swing.JComboBox();
        jLabel2 = new javax.swing.JLabel();
        tgl1 = new javax.swing.JComboBox();
        bln1 = new javax.swing.JComboBox();
        thn1 = new javax.swing.JComboBox();
        show = new javax.swing.JButton();
        show1 = new javax.swing.JButton();
        jPanel1 = new javax.swing.JPanel();
        total = new javax.swing.JTextField();
        jLabel4 = new javax.swing.JLabel();

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);
        setUndecorated(true);

        frame.setBackground(new java.awt.Color(51, 51, 51));

        tabel.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {
                {},
                {},
                {},
                {}
            },
            new String [] {

            }
        ));
        jScrollPane1.setViewportView(tabel);

        jButton7.setBackground(new java.awt.Color(255, 255, 255));
        jButton7.setFont(new java.awt.Font("Arial Black", 1, 11)); // NOI18N
        jButton7.setForeground(new java.awt.Color(102, 102, 0));
        jButton7.setText("<");
        jButton7.setBorder(javax.swing.BorderFactory.createEmptyBorder(1, 1, 1, 1));
        jButton7.setCursor(new java.awt.Cursor(java.awt.Cursor.HAND_CURSOR));
        jButton7.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton7ActionPerformed(evt);
            }
        });

        jButton5.setBackground(new java.awt.Color(255, 255, 255));
        jButton5.setFont(new java.awt.Font("Arial Black", 1, 11)); // NOI18N
        jButton5.setForeground(new java.awt.Color(51, 51, 0));
        jButton5.setText("--");
        jButton5.setBorder(javax.swing.BorderFactory.createEmptyBorder(1, 1, 1, 1));
        jButton5.setCursor(new java.awt.Cursor(java.awt.Cursor.HAND_CURSOR));
        jButton5.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton5ActionPerformed(evt);
            }
        });

        jButton4.setBackground(new java.awt.Color(204, 51, 0));
        jButton4.setFont(new java.awt.Font("Arial Black", 1, 11)); // NOI18N
        jButton4.setForeground(new java.awt.Color(254, 254, 254));
        jButton4.setText("X");
        jButton4.setBorder(javax.swing.BorderFactory.createEmptyBorder(1, 1, 1, 1));
        jButton4.setCursor(new java.awt.Cursor(java.awt.Cursor.HAND_CURSOR));
        jButton4.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton4ActionPerformed(evt);
            }
        });

        jPanel2.setBackground(new java.awt.Color(153, 204, 255));

        jLabel1.setFont(new java.awt.Font("Tahoma", 1, 11)); // NOI18N
        jLabel1.setForeground(new java.awt.Color(51, 51, 51));
        jLabel1.setText("Dari :");

        tgl.setModel(new javax.swing.DefaultComboBoxModel(new String[] { "01", "02", "03", "04", "05", "06", "07", "08", "09", "10", "11", "12", "13", "14", "15", "16", "17", "18", "19", "20", "21", "22", "23", "24", "25", "26", "27", "28", "29", "30", "31" }));
        tgl.setBorder(javax.swing.BorderFactory.createEmptyBorder(1, 1, 1, 1));

        bln.setModel(new javax.swing.DefaultComboBoxModel(new String[] { "01", "02", "03", "04", "05", "06", "07", "08", "09", "10", "11", "12" }));
        bln.setBorder(javax.swing.BorderFactory.createEmptyBorder(1, 1, 1, 1));

        thn.setBorder(javax.swing.BorderFactory.createEmptyBorder(1, 1, 1, 1));

        jLabel2.setFont(new java.awt.Font("Tahoma", 1, 11)); // NOI18N
        jLabel2.setForeground(new java.awt.Color(51, 51, 51));
        jLabel2.setText("Ke :");

        tgl1.setModel(new javax.swing.DefaultComboBoxModel(new String[] { "01", "02", "03", "04", "05", "06", "07", "08", "09", "10", "11", "12", "13", "14", "15", "16", "17", "18", "19", "20", "21", "22", "23", "24", "25", "26", "27", "28", "29", "30", "31" }));
        tgl1.setBorder(javax.swing.BorderFactory.createEmptyBorder(1, 1, 1, 1));

        bln1.setModel(new javax.swing.DefaultComboBoxModel(new String[] { "01", "02", "03", "04", "05", "06", "07", "08", "09", "10", "11", "12" }));
        bln1.setBorder(javax.swing.BorderFactory.createEmptyBorder(1, 1, 1, 1));

        thn1.setBorder(javax.swing.BorderFactory.createEmptyBorder(1, 1, 1, 1));

        show.setBackground(new java.awt.Color(255, 255, 255));
        show.setFont(new java.awt.Font("Arial Narrow", 1, 11)); // NOI18N
        show.setForeground(new java.awt.Color(51, 51, 0));
        show.setText("Transaksi");
        show.setBorder(javax.swing.BorderFactory.createEmptyBorder(1, 1, 1, 1));
        show.setCursor(new java.awt.Cursor(java.awt.Cursor.HAND_CURSOR));
        show.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                showActionPerformed(evt);
            }
        });

        show1.setBackground(new java.awt.Color(255, 255, 255));
        show1.setFont(new java.awt.Font("Arial Narrow", 1, 11)); // NOI18N
        show1.setForeground(new java.awt.Color(51, 51, 0));
        show1.setText("Brand");
        show1.setBorder(javax.swing.BorderFactory.createEmptyBorder(1, 1, 1, 1));
        show1.setCursor(new java.awt.Cursor(java.awt.Cursor.HAND_CURSOR));
        show1.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                show1ActionPerformed(evt);
            }
        });

        javax.swing.GroupLayout jPanel2Layout = new javax.swing.GroupLayout(jPanel2);
        jPanel2.setLayout(jPanel2Layout);
        jPanel2Layout.setHorizontalGroup(
            jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel2Layout.createSequentialGroup()
                .addContainerGap()
                .addComponent(jLabel1)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addComponent(tgl, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(bln, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(thn, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(jLabel2)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(tgl1, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(bln1, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(thn1, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(show, javax.swing.GroupLayout.PREFERRED_SIZE, 47, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addComponent(show1, javax.swing.GroupLayout.PREFERRED_SIZE, 47, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
        );
        jPanel2Layout.setVerticalGroup(
            jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel2Layout.createSequentialGroup()
                .addGap(2, 2, 2)
                .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.CENTER)
                    .addComponent(jLabel1)
                    .addComponent(tgl, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(thn, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(bln, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(jLabel2)
                    .addComponent(tgl1, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(thn1, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(bln1, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(show, javax.swing.GroupLayout.PREFERRED_SIZE, 25, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(show1, javax.swing.GroupLayout.PREFERRED_SIZE, 25, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(2, 2, 2))
        );

        javax.swing.GroupLayout frameLayout = new javax.swing.GroupLayout(frame);
        frame.setLayout(frameLayout);
        frameLayout.setHorizontalGroup(
            frameLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(jScrollPane1, javax.swing.GroupLayout.DEFAULT_SIZE, 760, Short.MAX_VALUE)
            .addGroup(frameLayout.createSequentialGroup()
                .addComponent(jPanel2, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addComponent(jButton7, javax.swing.GroupLayout.PREFERRED_SIZE, 33, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(jButton5, javax.swing.GroupLayout.PREFERRED_SIZE, 33, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(jButton4, javax.swing.GroupLayout.PREFERRED_SIZE, 33, javax.swing.GroupLayout.PREFERRED_SIZE))
        );
        frameLayout.setVerticalGroup(
            frameLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(frameLayout.createSequentialGroup()
                .addGroup(frameLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(frameLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                        .addComponent(jButton7, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                        .addComponent(jButton5, javax.swing.GroupLayout.Alignment.TRAILING, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                        .addComponent(jButton4, javax.swing.GroupLayout.Alignment.TRAILING, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
                    .addGroup(frameLayout.createSequentialGroup()
                        .addContainerGap()
                        .addComponent(jPanel2, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addComponent(jScrollPane1, javax.swing.GroupLayout.DEFAULT_SIZE, 373, Short.MAX_VALUE))
        );

        jPanel1.setBackground(new java.awt.Color(255, 204, 204));
        jPanel1.setBorder(javax.swing.BorderFactory.createEtchedBorder());

        total.setBackground(new java.awt.Color(254, 254, 254));
        total.setFont(new java.awt.Font("SansSerif", 1, 13)); // NOI18N
        total.setForeground(new java.awt.Color(116, 94, 94));
        total.setBorder(javax.swing.BorderFactory.createEtchedBorder());
        total.setFocusable(false);
        total.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                totalActionPerformed(evt);
            }
        });

        jLabel4.setFont(new java.awt.Font("Tahoma", 1, 11)); // NOI18N
        jLabel4.setForeground(new java.awt.Color(102, 102, 102));
        jLabel4.setText("Total Penjualan");

        javax.swing.GroupLayout jPanel1Layout = new javax.swing.GroupLayout(jPanel1);
        jPanel1.setLayout(jPanel1Layout);
        jPanel1Layout.setHorizontalGroup(
            jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel1Layout.createSequentialGroup()
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addComponent(jLabel4)
                .addGap(18, 18, 18)
                .addComponent(total, javax.swing.GroupLayout.PREFERRED_SIZE, 175, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap())
        );
        jPanel1Layout.setVerticalGroup(
            jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel1Layout.createSequentialGroup()
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(total, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(jLabel4))
                .addContainerGap())
        );

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(frame, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
            .addComponent(jPanel1, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addComponent(frame, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(0, 0, 0)
                .addComponent(jPanel1, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
        );

        pack();
    }// </editor-fold>//GEN-END:initComponents

    private void jButton7ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton7ActionPerformed
        // TODO add your handling code here:
        new MenuUtama().show();
        this.dispose();
    }//GEN-LAST:event_jButton7ActionPerformed

    private void jButton5ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton5ActionPerformed
        // TODO add your handling code here:
        setState(ICONIFIED);
    }//GEN-LAST:event_jButton5ActionPerformed

    private void jButton4ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton4ActionPerformed
        // TODO add your handling code here:
        System.exit(0);
    }//GEN-LAST:event_jButton4ActionPerformed

    private void showActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_showActionPerformed
        // TODO add your handling code here:
        //JOptionPane.showMessageDialog(rootPane, bln.getSelectedItem()+tgl.getSelectedItem());
        String tahun = (String) thn.getSelectedItem();
        String bulan = (String) bln.getSelectedItem();
        String hari = (String) tgl.getSelectedItem();
        String tahun2 = (String) thn1.getSelectedItem();
        String bulan2 = (String) bln1.getSelectedItem();
        String hari2 = (String) tgl1.getSelectedItem();
        String dari = (tahun+'-'+bulan+'-'+hari);
        String ke = (tahun2+'-'+bulan2+'-'+hari2);
        //System.out.println(dari);
        String carisql= "select * from transaksi where tanggal between '"+dari+"' and '"+ke+"'";
        tableview(carisql);
        penjumlahan();
    }//GEN-LAST:event_showActionPerformed

    private void totalActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_totalActionPerformed
        // TODO add your handling code here:
        
    }//GEN-LAST:event_totalActionPerformed

    private void show1ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_show1ActionPerformed
        // TODO add your handling code here:
        databrand();
    }//GEN-LAST:event_show1ActionPerformed

    /**
     * @param args the command line arguments
     */
    public static void main(String args[]) {
        /* Set the Nimbus look and feel */
        //<editor-fold defaultstate="collapsed" desc=" Look and feel setting code (optional) ">
        /* If Nimbus (introduced in Java SE 6) is not available, stay with the default look and feel.
         * For details see http://download.oracle.com/javase/tutorial/uiswing/lookandfeel/plaf.html 
         */
        try {
            for (javax.swing.UIManager.LookAndFeelInfo info : javax.swing.UIManager.getInstalledLookAndFeels()) {
                if ("Nimbus".equals(info.getName())) {
                    javax.swing.UIManager.setLookAndFeel(info.getClassName());
                    break;
                }
            }
        } catch (ClassNotFoundException ex) {
            java.util.logging.Logger.getLogger(laporandata.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (InstantiationException ex) {
            java.util.logging.Logger.getLogger(laporandata.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (IllegalAccessException ex) {
            java.util.logging.Logger.getLogger(laporandata.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (javax.swing.UnsupportedLookAndFeelException ex) {
            java.util.logging.Logger.getLogger(laporandata.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        }
        //</editor-fold>

        /* Create and display the form */
        java.awt.EventQueue.invokeLater(new Runnable() {
            public void run() {
                new laporandata().setVisible(true);
            }
        });
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JComboBox bln;
    private javax.swing.JComboBox bln1;
    private javax.swing.JPanel frame;
    private javax.swing.JButton jButton4;
    private javax.swing.JButton jButton5;
    private javax.swing.JButton jButton7;
    private javax.swing.JLabel jLabel1;
    private javax.swing.JLabel jLabel2;
    private javax.swing.JLabel jLabel4;
    private javax.swing.JPanel jPanel1;
    private javax.swing.JPanel jPanel2;
    private javax.swing.JScrollPane jScrollPane1;
    private javax.swing.JButton show;
    private javax.swing.JButton show1;
    private javax.swing.JTable tabel;
    private javax.swing.JComboBox tgl;
    private javax.swing.JComboBox tgl1;
    private javax.swing.JComboBox thn;
    private javax.swing.JComboBox thn1;
    private javax.swing.JTextField total;
    // End of variables declaration//GEN-END:variables
}
