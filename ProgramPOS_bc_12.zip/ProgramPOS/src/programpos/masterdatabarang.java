/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package programpos;

import java.awt.Color;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.text.SimpleDateFormat;
import java.util.Date;
import javax.swing.JButton;
import javax.swing.JOptionPane;
import java.awt.event.KeyEvent;
import javax.swing.table.DefaultTableModel;
import javax.swing.table.TableColumn;

/**
 *
 * @author YDN
 */
public class masterdatabarang extends javax.swing.JFrame {

    /**
     * Creates new form masterdatabarang
     */
    public masterdatabarang() {
        initComponents();
        setLocationRelativeTo(this);
        autokode2();
        autokode3();
        tabeltampil();
        tampiltabel2();
        memilihdata();
        EDIT.setEnabled(false);
        Laporan3.setEnabled(false);
        nm_brand.requestFocus();
        tglhari();
    }
    public String ibr, br, nm;
    public String getidbr(){
        return ibr;
    }
    public String getbr(){
        return br;
    }
    public String nm(){
        return nm;
    }
    //data yang akan masuk ke inputan
    public void itempilih(){
        barang1 br = new barang1();
        br.mb= this;
        idbr.setText(ibr);
        //JOptionPane.showMessageDialog(rootPane, nm);
    }
    public void huruf(KeyEvent a){
        if (Character.isAlphabetic(a.getKeyChar())) {
            a.consume();
        }
    }
    private void tglhari(){
        Date now = new Date();
        SimpleDateFormat sdf = new SimpleDateFormat("dd-MM-yyyy");
        String tglH = sdf.format(now);
        tgl.setText(tglH);
    }
    public void simpanjmlah(){
        if ("".equals(idbj.getText())||"".equals(idbr.getText())||"".equals(hrg.getText())||"".equals(jml.getText())
                ||"".equals(uk.getSelectedItem())||"".equals(tgl.getText())) {
            JOptionPane.showMessageDialog(rootPane, "Inputan Belum Lengkap");
        }else{
            String sql = "insert into barang2 (idb2, idb1, harga, jumlah, ukuran, tanggal) values"
                    + "('"+idbj.getText()+"','"+idbr.getText()+"','"+hrg.getText()+"','"+jml.getText()+"','"+uk.getSelectedItem()+"'"
                    + ",'"+tgl.getText()+"')";
            int i = koneksiDB.execute(sql);
            if (i == 1) {
                JOptionPane.showMessageDialog(rootPane, "Data Telah ditambahkan");
                autokode2();
                idbr.requestFocus();
                tampiltabel2();
                kosongka2();
            }else{
                JOptionPane.showMessageDialog(rootPane, "data tidak terhubung");
            }
        }
    }
    public void simpanT(){
        if ("".equals(id_brg.getText()) ||"".equals(nm_brand.getText())||"".equals(nama.getText())) {
            JOptionPane.showMessageDialog(rootPane, "Data Belum Lengkap");
        }else{
            String sql = "insert into barang1 (idb,brand,nama,jenis)"
                    + "values ('"+id_brg.getText()+"','"+nm_brand.getText()+"','"+nama.getText()+"',"
                    + "'"+opsi.getSelectedItem()+"')";
            int i = koneksiDB.execute(sql);
            if (i == 1) {
                JOptionPane.showMessageDialog(rootPane, "data terhubung");
                kosongkan();
                tabeltampil();
                autokode2();
                nm_brand.requestFocus();
            }else{
                JOptionPane.showMessageDialog(rootPane, "data tidak terhubung");
            }
        }
    }
    public void updatedata(){
        String sql = "UPDATE barang1 SET brand ='"+nm_brand.getText()+"',"
                + "nama = '"+nama.getText()+"',"
                + "jenis ='"+opsi.getSelectedItem()+"'"
                + "where idb = '"+id_brg.getText()+"'";
            int status = koneksiDB.execute(sql);
            if (status == 1) {
                JOptionPane.showMessageDialog(this,"data telah di PERBAHARUI","SUKSES",JOptionPane.INFORMATION_MESSAGE);
                
            }else{
                JOptionPane.showMessageDialog(this, "data gagal di PERBAHARUI", "GAGAL",JOptionPane.ERROR_MESSAGE);
            }
    }
    public void updatedata2(){
        String sql = "update barang2 set idb1 = '"+idbr.getText()+"',harga='"+hrg.getText()+"',jumlah='"+jml.getText()+"',"
                + "ukuran='"+uk.getSelectedItem()+"',tanggal='"+tgl.getText()+"'"
                + "where idb2 = '"+idbj.getText()+"'";
        int stt = koneksiDB.execute(sql);
        if (stt == 1) {
                JOptionPane.showMessageDialog(this, "data  di PERBAHARUI", "GAGAL",JOptionPane.ERROR_MESSAGE);
        }
    }
    void kosongka2(){
        idbj.setText(""); idbr.setText(""); hrg.setText(""); jml.setText(""); //uk.setText("");
    }
    public void kosongkan(){
        id_brg.setText(""); opsi.setSelectedItem("");
        nm_brand.setText(""); nama.setText("");  
    }
    public void autokode2(){
        try {
            String sql =  "SELECT right(idb,2) FROM barang1";
            String query = "select max(substring(idb, 4,5))+1 from barang1";
            ResultSet qr = koneksiDB.executeQuery(query);
            ResultSet rs = koneksiDB.executeQuery(sql);
            if (rs.first()==false) {
                id_brg.setText("B1-001");
            }else{
                while (qr.next()) {
                    String ambil = qr.getString(1);
                    id_brg.setText(String.format("B1-%03d", Integer.parseInt(ambil))); 
                }  
            }
        } catch (SQLException e) {
        }
    } 
        public void autokode3(){
        try {
            String sql =  "SELECT right(idb2,2) FROM barang2";
            String query = "select max(substring(idb2, 4,5))+1 from barang2";
            ResultSet qr = koneksiDB.executeQuery(query);
            ResultSet rs = koneksiDB.executeQuery(sql);
            if (rs.first()==false) {
                idbj.setText("B2-001");
            }else{
                while (qr.next()) {
                    String ambil = qr.getString(1);
                    idbj.setText(String.format("B2-%03d", Integer.parseInt(ambil))); 
                }  
            }
        } catch (SQLException e) {
        }
    }
        public void caridata(String sql){
            String kolom[] = {"ID","Brand","Nama","Jenis"};
            DefaultTableModel tb = new DefaultTableModel(null, kolom);          
        try {
            ResultSet rs = koneksiDB.executeQuery(sql);
            while (rs.next()){
                String id = rs.getString(1);
                String nm_b = rs.getString(2);
                String nm = rs.getString(3);
                String jns = rs.getString(4);                
                String data[] = {id,nm_b,nm,jns};
                tb.addRow(data);
            }
        }catch(Exception e){
            tabeltampil();
        }jTable3.setModel(tb);
        }
    public void tabeltampil(){
        String kolom[] = {"ID","Brand","Nama","Jenis"};
        DefaultTableModel tb = new DefaultTableModel(null, kolom);
        String sql = "select * from barang1";
        ResultSet rs = koneksiDB.executeQuery(sql);
        try {
            while (rs.next()){
                String id = rs.getString(1);
                String nm_b = rs.getString(2);
                String nm = rs.getString(3);
                String jns = rs.getString(4);
                
                String data[] = {id,nm_b,nm,jns};
                tb.addRow(data);
            }
        } catch (Exception e) {
        }
        jTable3.setModel(tb);lebarkolom1();
    }
    public void caridata2(String sql){
        String kolom[]={"Kode","Id Barang","Brand","Nama","UK","Qty","Harga","Tanggal"};
        DefaultTableModel tb = new DefaultTableModel(null, kolom);
        ResultSet rs = koneksiDB.executeQuery(sql);
        try {
            while(rs.next()){
                 String id = rs.getString(1);
                String id2 = rs.getString(2);
                String br = rs.getString(3);
                String nm = rs.getString(4);
                String uk = rs.getString(5);
                String jm = rs.getString(6);
                String hg = rs.getString(7);
                String tg = rs.getString(8);
                String data[]={id,id2,br,nm,uk,jm,hg,tg};
                tb.addRow(data);
            }
        } catch (Exception e) {
        }
        tbjuml.setModel(tb);        
    }
        public void lebarkolom1(){
        TableColumn clm;
        //tbjuml.setAutoResizeMode(javax.swing.JTable.AUTO_RESIZE_OFF);
        clm = 
        jTable3.getColumnModel().getColumn(0);
        clm.setPreferredWidth(50);
        clm = 
        jTable3.getColumnModel().getColumn(1);
        clm.setPreferredWidth(150);
        clm = 
        jTable3.getColumnModel().getColumn(2);
        clm.setPreferredWidth(300);
        clm = 
        jTable3.getColumnModel().getColumn(3);
        clm.setPreferredWidth(100);
    }
    public void lebarkolom(){
        TableColumn clm;
        //tbjuml.setAutoResizeMode(javax.swing.JTable.AUTO_RESIZE_OFF);
        clm = 
        tbjuml.getColumnModel().getColumn(0);
        clm.setPreferredWidth(80);
        clm = 
        tbjuml.getColumnModel().getColumn(1);
        clm.setPreferredWidth(80);
        clm = 
        tbjuml.getColumnModel().getColumn(2);
        clm.setPreferredWidth(200);
        clm = 
        tbjuml.getColumnModel().getColumn(3);
        clm.setPreferredWidth(300);
        clm = 
        tbjuml.getColumnModel().getColumn(4);
        clm.setPreferredWidth(100);
        clm = 
        tbjuml.getColumnModel().getColumn(5);
        clm.setPreferredWidth(80);
        clm = 
        tbjuml.getColumnModel().getColumn(6);
        clm.setPreferredWidth(80);
        clm = 
        tbjuml.getColumnModel().getColumn(7);
        clm.setPreferredWidth(80);   
    }
    void tampiltabel2(){
        String kolom[]={"Kode","Id Barang","Brand","Nama","UK","Qty","Harga","Tanggal"};
        DefaultTableModel tb = new DefaultTableModel(null, kolom);
        String sql = "SELECT idb2,idb,brand,nama,ukuran,jumlah,harga,tanggal\n" +
                     "FROM barang1, barang2\n" +
                     "WHERE barang1.`idb`=`barang2`.`idb1`";
        ResultSet rs = koneksiDB.executeQuery(sql);
        try {
            while(rs.next()){
                String id = rs.getString(1);
                String id2 = rs.getString(2);
                String br = rs.getString(3);
                String nm = rs.getString(4);
                String uk = rs.getString(5);
                String jm = rs.getString(6);
                String hg = rs.getString(7);
                String tg = rs.getString(8);
                String data[]={id,id2,br,nm,uk,jm,hg,tg};
                tb.addRow(data);
            }
        } catch (Exception e) {
        }tbjuml.setModel(tb); lebarkolom();
    }
    public void memilihdata(){
        int baris = jTable3.getSelectedRow();
        if (baris != -1) {
            id_brg.setText(jTable3.getValueAt(baris, 0).toString());
            nm_brand.setText(jTable3.getValueAt(baris, 1).toString());
            nama.setText(jTable3.getValueAt(baris, 2).toString());
            opsi.setSelectedItem(jTable3.getValueAt(baris, 3).toString());
        }
    }
    public void memilihdata1(){
        int baris = tbjuml.getSelectedRow();
        if (baris !=-1) {
            idbj.setText(tbjuml.getValueAt(baris, 0).toString());
            idbr.setText(tbjuml.getValueAt(baris, 1).toString());
            hrg.setText(tbjuml.getValueAt(baris, 6).toString());
            jml.setText(tbjuml.getValueAt(baris, 5).toString());
            uk.setSelectedItem(tbjuml.getValueAt(baris, 4).toString());
            tgl.setText(tbjuml.getValueAt(baris, 7).toString());
        }
    }
    /**
     * This method is called from within the constructor to initialize the form.
     * WARNING: Do NOT modify this code. The content of this method is always
     * regenerated by the Form Editor.
     */
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jPanel3 = new javax.swing.JPanel();
        jPanel1 = new javax.swing.JPanel();
        jTabbedPane1 = new javax.swing.JTabbedPane();
        jPanel6 = new javax.swing.JPanel();
        jPanel7 = new javax.swing.JPanel();
        jLabel24 = new javax.swing.JLabel();
        nm_brand = new javax.swing.JTextField();
        jLabel25 = new javax.swing.JLabel();
        nama = new javax.swing.JTextField();
        jLabel26 = new javax.swing.JLabel();
        jLabel27 = new javax.swing.JLabel();
        jLabel28 = new javax.swing.JLabel();
        jLabel29 = new javax.swing.JLabel();
        opsi = new javax.swing.JComboBox();
        id_brg = new javax.swing.JTextField();
        jLabel36 = new javax.swing.JLabel();
        jLabel37 = new javax.swing.JLabel();
        jPanel9 = new javax.swing.JPanel();
        EDIT = new javax.swing.JButton();
        Laporan5 = new javax.swing.JButton();
        caridata1 = new javax.swing.JTextField();
        jLabel2 = new javax.swing.JLabel();
        jScrollPane3 = new javax.swing.JScrollPane();
        jTable3 = new javax.swing.JTable();
        simpan = new javax.swing.JButton();
        jPanel5 = new javax.swing.JPanel();
        jPanel4 = new javax.swing.JPanel();
        jLabel7 = new javax.swing.JLabel();
        jLabel10 = new javax.swing.JLabel();
        hrg = new javax.swing.JTextField();
        jLabel16 = new javax.swing.JLabel();
        jLabel17 = new javax.swing.JLabel();
        jLabel20 = new javax.swing.JLabel();
        jLabel22 = new javax.swing.JLabel();
        jml = new javax.swing.JTextField();
        jLabel19 = new javax.swing.JLabel();
        jLabel18 = new javax.swing.JLabel();
        simpanbj = new javax.swing.JButton();
        idbj = new javax.swing.JTextField();
        jLabel21 = new javax.swing.JLabel();
        jLabel23 = new javax.swing.JLabel();
        idbr = new javax.swing.JTextField();
        jLabel30 = new javax.swing.JLabel();
        jLabel31 = new javax.swing.JLabel();
        jPanel10 = new javax.swing.JPanel();
        Laporan3 = new javax.swing.JButton();
        Laporan1 = new javax.swing.JButton();
        caridt2 = new javax.swing.JTextField();
        jScrollPane2 = new javax.swing.JScrollPane();
        tbjuml = new javax.swing.JTable();
        jLabel1 = new javax.swing.JLabel();
        Laporan6 = new javax.swing.JButton();
        tgl = new javax.swing.JTextField();
        uk = new javax.swing.JComboBox();
        jPanel2 = new javax.swing.JPanel();
        jLabel15 = new javax.swing.JLabel();
        jButton5 = new javax.swing.JButton();
        jButton4 = new javax.swing.JButton();
        jButton7 = new javax.swing.JButton();

        javax.swing.GroupLayout jPanel3Layout = new javax.swing.GroupLayout(jPanel3);
        jPanel3.setLayout(jPanel3Layout);
        jPanel3Layout.setHorizontalGroup(
            jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 100, Short.MAX_VALUE)
        );
        jPanel3Layout.setVerticalGroup(
            jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 100, Short.MAX_VALUE)
        );

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);
        setUndecorated(true);

        jPanel1.setBackground(new java.awt.Color(102, 102, 102));

        jPanel6.setBackground(new java.awt.Color(255, 255, 255));

        jPanel7.setBackground(new java.awt.Color(204, 255, 204));

        jLabel24.setFont(new java.awt.Font("SansSerif", 1, 13)); // NOI18N
        jLabel24.setForeground(new java.awt.Color(116, 94, 94));
        jLabel24.setText("Brand");

        nm_brand.setBackground(new java.awt.Color(254, 254, 254));
        nm_brand.setFont(new java.awt.Font("SansSerif", 1, 13)); // NOI18N
        nm_brand.setForeground(new java.awt.Color(116, 94, 94));
        nm_brand.setBorder(javax.swing.BorderFactory.createEtchedBorder());
        nm_brand.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                nm_brandActionPerformed(evt);
            }
        });

        jLabel25.setFont(new java.awt.Font("SansSerif", 1, 13)); // NOI18N
        jLabel25.setForeground(new java.awt.Color(116, 94, 94));
        jLabel25.setText(":");

        nama.setBackground(new java.awt.Color(254, 254, 254));
        nama.setFont(new java.awt.Font("SansSerif", 1, 13)); // NOI18N
        nama.setForeground(new java.awt.Color(116, 94, 94));
        nama.setBorder(javax.swing.BorderFactory.createEtchedBorder());
        nama.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                namaActionPerformed(evt);
            }
        });

        jLabel26.setFont(new java.awt.Font("SansSerif", 1, 13)); // NOI18N
        jLabel26.setForeground(new java.awt.Color(116, 94, 94));
        jLabel26.setText(":");

        jLabel27.setFont(new java.awt.Font("SansSerif", 1, 13)); // NOI18N
        jLabel27.setForeground(new java.awt.Color(116, 94, 94));
        jLabel27.setText("Nama Item");

        jLabel28.setFont(new java.awt.Font("SansSerif", 1, 13)); // NOI18N
        jLabel28.setForeground(new java.awt.Color(116, 94, 94));
        jLabel28.setText(":");

        jLabel29.setFont(new java.awt.Font("SansSerif", 1, 13)); // NOI18N
        jLabel29.setForeground(new java.awt.Color(116, 94, 94));
        jLabel29.setText("Jenis");

        opsi.setModel(new javax.swing.DefaultComboBoxModel(new String[] { "BAJU", "CELANA", "SEPATU", "TOPI", " " }));
        opsi.setBorder(javax.swing.BorderFactory.createEtchedBorder());

        id_brg.setBackground(new java.awt.Color(254, 254, 254));
        id_brg.setFont(new java.awt.Font("SansSerif", 1, 13)); // NOI18N
        id_brg.setForeground(new java.awt.Color(116, 94, 94));
        id_brg.setBorder(javax.swing.BorderFactory.createEtchedBorder());
        id_brg.setFocusable(false);
        id_brg.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                id_brgActionPerformed(evt);
            }
        });

        jLabel36.setFont(new java.awt.Font("SansSerif", 1, 13)); // NOI18N
        jLabel36.setForeground(new java.awt.Color(116, 94, 94));
        jLabel36.setText(":");

        jLabel37.setFont(new java.awt.Font("SansSerif", 1, 13)); // NOI18N
        jLabel37.setForeground(new java.awt.Color(116, 94, 94));
        jLabel37.setText("Id");

        jPanel9.setBackground(new java.awt.Color(255, 255, 204));
        jPanel9.setBorder(javax.swing.BorderFactory.createMatteBorder(1, 0, 1, 0, new java.awt.Color(102, 102, 102)));

        EDIT.setBackground(new java.awt.Color(1, 1, 1));
        EDIT.setForeground(new java.awt.Color(219, 219, 219));
        EDIT.setText("Update");
        EDIT.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                EDITActionPerformed(evt);
            }
        });

        Laporan5.setBackground(new java.awt.Color(1, 1, 1));
        Laporan5.setForeground(new java.awt.Color(219, 219, 219));
        Laporan5.setText("New");
        Laporan5.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                Laporan5ActionPerformed(evt);
            }
        });

        caridata1.setBackground(new java.awt.Color(254, 254, 254));
        caridata1.setFont(new java.awt.Font("SansSerif", 1, 13)); // NOI18N
        caridata1.setForeground(new java.awt.Color(116, 94, 94));
        caridata1.setBorder(javax.swing.BorderFactory.createEtchedBorder());
        caridata1.addKeyListener(new java.awt.event.KeyAdapter() {
            public void keyReleased(java.awt.event.KeyEvent evt) {
                caridata1KeyReleased(evt);
            }
        });

        jLabel2.setText("Cari");

        jTable3.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null}
            },
            new String [] {
                "Title 1", "Title 2", "Title 3", "Title 4"
            }
        ));
        jTable3.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                jTable3MouseClicked(evt);
            }
        });
        jScrollPane3.setViewportView(jTable3);

        javax.swing.GroupLayout jPanel9Layout = new javax.swing.GroupLayout(jPanel9);
        jPanel9.setLayout(jPanel9Layout);
        jPanel9Layout.setHorizontalGroup(
            jPanel9Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel9Layout.createSequentialGroup()
                .addContainerGap()
                .addComponent(Laporan5, javax.swing.GroupLayout.PREFERRED_SIZE, 72, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addComponent(EDIT)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addComponent(jLabel2)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addComponent(caridata1, javax.swing.GroupLayout.PREFERRED_SIZE, 157, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap())
            .addComponent(jScrollPane3, javax.swing.GroupLayout.Alignment.TRAILING)
        );
        jPanel9Layout.setVerticalGroup(
            jPanel9Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel9Layout.createSequentialGroup()
                .addGroup(jPanel9Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(jPanel9Layout.createSequentialGroup()
                        .addContainerGap()
                        .addGroup(jPanel9Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.CENTER)
                            .addComponent(jLabel2)
                            .addComponent(caridata1, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)))
                    .addGroup(jPanel9Layout.createSequentialGroup()
                        .addGap(12, 12, 12)
                        .addComponent(Laporan5))
                    .addGroup(jPanel9Layout.createSequentialGroup()
                        .addGap(12, 12, 12)
                        .addComponent(EDIT)))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addComponent(jScrollPane3, javax.swing.GroupLayout.PREFERRED_SIZE, 272, javax.swing.GroupLayout.PREFERRED_SIZE))
        );

        simpan.setBackground(new java.awt.Color(1, 1, 1));
        simpan.setForeground(new java.awt.Color(219, 219, 219));
        simpan.setText("Oke");
        simpan.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                simpanActionPerformed(evt);
            }
        });

        javax.swing.GroupLayout jPanel7Layout = new javax.swing.GroupLayout(jPanel7);
        jPanel7.setLayout(jPanel7Layout);
        jPanel7Layout.setHorizontalGroup(
            jPanel7Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(jPanel9, javax.swing.GroupLayout.Alignment.TRAILING, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
            .addGroup(jPanel7Layout.createSequentialGroup()
                .addGap(18, 18, 18)
                .addComponent(jLabel37)
                .addGap(2, 2, 2)
                .addComponent(jLabel36)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addComponent(id_brg, javax.swing.GroupLayout.PREFERRED_SIZE, 89, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(jLabel24)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(jLabel25)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(nm_brand, javax.swing.GroupLayout.PREFERRED_SIZE, 103, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(jLabel27)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(jLabel26)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addComponent(nama, javax.swing.GroupLayout.PREFERRED_SIZE, 112, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addComponent(jLabel29)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(jLabel28)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(opsi, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addComponent(simpan, javax.swing.GroupLayout.DEFAULT_SIZE, 81, Short.MAX_VALUE)
                .addGap(8, 8, 8))
        );
        jPanel7Layout.setVerticalGroup(
            jPanel7Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel7Layout.createSequentialGroup()
                .addContainerGap()
                .addGroup(jPanel7Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel37)
                    .addComponent(id_brg, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(jLabel36)
                    .addComponent(jLabel24)
                    .addComponent(jLabel25)
                    .addComponent(nm_brand, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(jLabel27)
                    .addComponent(jLabel26)
                    .addComponent(nama, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(jLabel29)
                    .addComponent(opsi, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(jLabel28)
                    .addComponent(simpan))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addComponent(jPanel9, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(308, 308, 308))
        );

        javax.swing.GroupLayout jPanel6Layout = new javax.swing.GroupLayout(jPanel6);
        jPanel6.setLayout(jPanel6Layout);
        jPanel6Layout.setHorizontalGroup(
            jPanel6Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(jPanel7, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
        );
        jPanel6Layout.setVerticalGroup(
            jPanel6Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(jPanel7, javax.swing.GroupLayout.PREFERRED_SIZE, 359, Short.MAX_VALUE)
        );

        jTabbedPane1.addTab("Barang Baru", jPanel6);

        jPanel5.setBackground(new java.awt.Color(255, 255, 255));
        jPanel5.setBorder(javax.swing.BorderFactory.createEtchedBorder());

        jPanel4.setBackground(new java.awt.Color(204, 255, 204));

        jLabel7.setFont(new java.awt.Font("SansSerif", 1, 13)); // NOI18N
        jLabel7.setForeground(new java.awt.Color(116, 94, 94));
        jLabel7.setText("Ukuran");

        jLabel10.setFont(new java.awt.Font("SansSerif", 1, 13)); // NOI18N
        jLabel10.setForeground(new java.awt.Color(116, 94, 94));
        jLabel10.setText(":");

        hrg.setBackground(new java.awt.Color(254, 254, 254));
        hrg.setFont(new java.awt.Font("SansSerif", 1, 13)); // NOI18N
        hrg.setForeground(new java.awt.Color(116, 94, 94));
        hrg.setBorder(javax.swing.BorderFactory.createEtchedBorder());
        hrg.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                hrgActionPerformed(evt);
            }
        });
        hrg.addKeyListener(new java.awt.event.KeyAdapter() {
            public void keyTyped(java.awt.event.KeyEvent evt) {
                hrgKeyTyped(evt);
            }
        });

        jLabel16.setFont(new java.awt.Font("SansSerif", 1, 13)); // NOI18N
        jLabel16.setForeground(new java.awt.Color(116, 94, 94));
        jLabel16.setText(":");

        jLabel17.setFont(new java.awt.Font("SansSerif", 1, 13)); // NOI18N
        jLabel17.setForeground(new java.awt.Color(116, 94, 94));
        jLabel17.setText("Harga");

        jLabel20.setFont(new java.awt.Font("SansSerif", 1, 13)); // NOI18N
        jLabel20.setForeground(new java.awt.Color(116, 94, 94));
        jLabel20.setText("Qty");

        jLabel22.setFont(new java.awt.Font("SansSerif", 1, 13)); // NOI18N
        jLabel22.setForeground(new java.awt.Color(116, 94, 94));
        jLabel22.setText(":");

        jml.setBackground(new java.awt.Color(254, 254, 254));
        jml.setFont(new java.awt.Font("SansSerif", 1, 13)); // NOI18N
        jml.setForeground(new java.awt.Color(116, 94, 94));
        jml.setBorder(javax.swing.BorderFactory.createEtchedBorder());
        jml.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jmlActionPerformed(evt);
            }
        });
        jml.addKeyListener(new java.awt.event.KeyAdapter() {
            public void keyTyped(java.awt.event.KeyEvent evt) {
                jmlKeyTyped(evt);
            }
        });

        jLabel19.setFont(new java.awt.Font("SansSerif", 1, 13)); // NOI18N
        jLabel19.setForeground(new java.awt.Color(116, 94, 94));
        jLabel19.setText(":");

        jLabel18.setFont(new java.awt.Font("SansSerif", 1, 13)); // NOI18N
        jLabel18.setForeground(new java.awt.Color(116, 94, 94));
        jLabel18.setText("Tanggal");

        simpanbj.setBackground(new java.awt.Color(1, 1, 1));
        simpanbj.setForeground(new java.awt.Color(219, 219, 219));
        simpanbj.setText("Simpan");
        simpanbj.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                simpanbjActionPerformed(evt);
            }
        });

        idbj.setBackground(new java.awt.Color(254, 254, 254));
        idbj.setFont(new java.awt.Font("SansSerif", 1, 13)); // NOI18N
        idbj.setForeground(new java.awt.Color(116, 94, 94));
        idbj.setBorder(javax.swing.BorderFactory.createEtchedBorder());
        idbj.setFocusable(false);
        idbj.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                idbjActionPerformed(evt);
            }
        });

        jLabel21.setFont(new java.awt.Font("SansSerif", 1, 13)); // NOI18N
        jLabel21.setForeground(new java.awt.Color(116, 94, 94));
        jLabel21.setText(":");

        jLabel23.setFont(new java.awt.Font("SansSerif", 1, 13)); // NOI18N
        jLabel23.setForeground(new java.awt.Color(116, 94, 94));
        jLabel23.setText("Kode");

        idbr.setBackground(new java.awt.Color(254, 254, 254));
        idbr.setFont(new java.awt.Font("SansSerif", 1, 13)); // NOI18N
        idbr.setForeground(new java.awt.Color(116, 94, 94));
        idbr.setBorder(javax.swing.BorderFactory.createEtchedBorder());
        idbr.setFocusable(false);
        idbr.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                idbrActionPerformed(evt);
            }
        });

        jLabel30.setFont(new java.awt.Font("SansSerif", 1, 13)); // NOI18N
        jLabel30.setForeground(new java.awt.Color(116, 94, 94));
        jLabel30.setText(":");

        jLabel31.setFont(new java.awt.Font("SansSerif", 1, 13)); // NOI18N
        jLabel31.setForeground(new java.awt.Color(116, 94, 94));
        jLabel31.setText("Id Barang");

        jPanel10.setBackground(new java.awt.Color(255, 255, 204));
        jPanel10.setBorder(javax.swing.BorderFactory.createEmptyBorder(1, 1, 1, 1));

        Laporan3.setBackground(new java.awt.Color(1, 1, 1));
        Laporan3.setForeground(new java.awt.Color(219, 219, 219));
        Laporan3.setText("Edit");
        Laporan3.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                Laporan3ActionPerformed(evt);
            }
        });

        Laporan1.setBackground(new java.awt.Color(1, 1, 1));
        Laporan1.setForeground(new java.awt.Color(219, 219, 219));
        Laporan1.setText("New");
        Laporan1.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                Laporan1ActionPerformed(evt);
            }
        });

        caridt2.setBackground(new java.awt.Color(254, 254, 254));
        caridt2.setFont(new java.awt.Font("SansSerif", 1, 13)); // NOI18N
        caridt2.setForeground(new java.awt.Color(116, 94, 94));
        caridt2.setBorder(javax.swing.BorderFactory.createEtchedBorder());
        caridt2.addKeyListener(new java.awt.event.KeyAdapter() {
            public void keyReleased(java.awt.event.KeyEvent evt) {
                caridt2KeyReleased(evt);
            }
        });

        tbjuml.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null}
            },
            new String [] {
                "Title 1", "Title 2", "Title 3", "Title 4"
            }
        ));
        tbjuml.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                tbjumlMouseClicked(evt);
            }
        });
        jScrollPane2.setViewportView(tbjuml);

        jLabel1.setText("Cari");

        javax.swing.GroupLayout jPanel10Layout = new javax.swing.GroupLayout(jPanel10);
        jPanel10.setLayout(jPanel10Layout);
        jPanel10Layout.setHorizontalGroup(
            jPanel10Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel10Layout.createSequentialGroup()
                .addContainerGap()
                .addComponent(Laporan1)
                .addGap(18, 18, 18)
                .addComponent(Laporan3)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addComponent(jLabel1)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addComponent(caridt2, javax.swing.GroupLayout.PREFERRED_SIZE, 131, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap())
            .addComponent(jScrollPane2, javax.swing.GroupLayout.Alignment.TRAILING, javax.swing.GroupLayout.DEFAULT_SIZE, 715, Short.MAX_VALUE)
        );
        jPanel10Layout.setVerticalGroup(
            jPanel10Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel10Layout.createSequentialGroup()
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addGroup(jPanel10Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.CENTER)
                    .addComponent(Laporan3)
                    .addComponent(Laporan1)
                    .addComponent(caridt2, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(jLabel1))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(jScrollPane2, javax.swing.GroupLayout.PREFERRED_SIZE, 237, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap())
        );

        Laporan6.setBackground(new java.awt.Color(1, 1, 1));
        Laporan6.setForeground(new java.awt.Color(219, 219, 219));
        Laporan6.setText("Cari");
        Laporan6.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                Laporan6ActionPerformed(evt);
            }
        });

        tgl.setBackground(new java.awt.Color(254, 254, 254));
        tgl.setFont(new java.awt.Font("SansSerif", 1, 13)); // NOI18N
        tgl.setForeground(new java.awt.Color(116, 94, 94));
        tgl.setBorder(javax.swing.BorderFactory.createEtchedBorder());
        tgl.setFocusable(false);
        tgl.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                tglActionPerformed(evt);
            }
        });
        tgl.addKeyListener(new java.awt.event.KeyAdapter() {
            public void keyTyped(java.awt.event.KeyEvent evt) {
                tglKeyTyped(evt);
            }
        });

        uk.setModel(new javax.swing.DefaultComboBoxModel(new String[] { "S", "M", "L", "XL", "XXL" }));
        uk.setBorder(javax.swing.BorderFactory.createEtchedBorder());

        javax.swing.GroupLayout jPanel4Layout = new javax.swing.GroupLayout(jPanel4);
        jPanel4.setLayout(jPanel4Layout);
        jPanel4Layout.setHorizontalGroup(
            jPanel4Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel4Layout.createSequentialGroup()
                .addGap(10, 10, 10)
                .addGroup(jPanel4Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(jLabel23, javax.swing.GroupLayout.Alignment.TRAILING)
                    .addComponent(jLabel20, javax.swing.GroupLayout.Alignment.TRAILING))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addGroup(jPanel4Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.CENTER)
                    .addComponent(jLabel22)
                    .addComponent(jLabel21))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addGroup(jPanel4Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                    .addComponent(idbj, javax.swing.GroupLayout.DEFAULT_SIZE, 54, Short.MAX_VALUE)
                    .addComponent(jml))
                .addGap(34, 34, 34)
                .addGroup(jPanel4Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(jLabel7, javax.swing.GroupLayout.Alignment.TRAILING)
                    .addComponent(jLabel31, javax.swing.GroupLayout.Alignment.TRAILING))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addGroup(jPanel4Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                    .addGroup(jPanel4Layout.createSequentialGroup()
                        .addComponent(jLabel30)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(idbr, javax.swing.GroupLayout.PREFERRED_SIZE, 74, javax.swing.GroupLayout.PREFERRED_SIZE))
                    .addGroup(jPanel4Layout.createSequentialGroup()
                        .addComponent(jLabel10)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(uk, 0, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(Laporan6, javax.swing.GroupLayout.PREFERRED_SIZE, 57, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addGroup(jPanel4Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                    .addComponent(jLabel18)
                    .addComponent(jLabel17))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addGroup(jPanel4Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.CENTER)
                    .addComponent(jLabel19)
                    .addComponent(jLabel16))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addGroup(jPanel4Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(hrg, javax.swing.GroupLayout.PREFERRED_SIZE, 91, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(tgl, javax.swing.GroupLayout.PREFERRED_SIZE, 91, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(18, 18, 18)
                .addComponent(simpanbj, javax.swing.GroupLayout.PREFERRED_SIZE, 130, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap())
            .addComponent(jPanel10, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
        );
        jPanel4Layout.setVerticalGroup(
            jPanel4Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel4Layout.createSequentialGroup()
                .addGroup(jPanel4Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(jPanel4Layout.createSequentialGroup()
                        .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                        .addGroup(jPanel4Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(jLabel23)
                            .addComponent(idbj, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(jLabel21)
                            .addComponent(jLabel31)
                            .addComponent(idbr, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(jLabel30)
                            .addComponent(jLabel17)
                            .addComponent(hrg, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(jLabel16)
                            .addComponent(Laporan6, javax.swing.GroupLayout.PREFERRED_SIZE, 23, javax.swing.GroupLayout.PREFERRED_SIZE))
                        .addGap(10, 10, 10)
                        .addGroup(jPanel4Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(jLabel7)
                            .addComponent(jLabel10)
                            .addComponent(jLabel18)
                            .addComponent(jLabel19)
                            .addComponent(jLabel20)
                            .addComponent(jml, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(jLabel22)
                            .addComponent(tgl, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(uk, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                        .addGap(3, 3, 3))
                    .addGroup(jPanel4Layout.createSequentialGroup()
                        .addContainerGap()
                        .addComponent(simpanbj, javax.swing.GroupLayout.PREFERRED_SIZE, 57, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGap(2, 2, 2)))
                .addComponent(jPanel10, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(249, 249, 249))
        );

        javax.swing.GroupLayout jPanel5Layout = new javax.swing.GroupLayout(jPanel5);
        jPanel5.setLayout(jPanel5Layout);
        jPanel5Layout.setHorizontalGroup(
            jPanel5Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(jPanel4, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
        );
        jPanel5Layout.setVerticalGroup(
            jPanel5Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(jPanel4, javax.swing.GroupLayout.PREFERRED_SIZE, 355, Short.MAX_VALUE)
        );

        jTabbedPane1.addTab("Jumlah Barang", jPanel5);

        jPanel2.setBackground(new java.awt.Color(102, 102, 102));

        jLabel15.setFont(new java.awt.Font("SansSerif", 1, 18)); // NOI18N
        jLabel15.setForeground(new java.awt.Color(242, 240, 240));
        jLabel15.setText("Master Barang");

        jButton5.setBackground(new java.awt.Color(255, 255, 255));
        jButton5.setFont(new java.awt.Font("Arial Black", 1, 11)); // NOI18N
        jButton5.setForeground(new java.awt.Color(51, 51, 0));
        jButton5.setText("--");
        jButton5.setBorder(javax.swing.BorderFactory.createEmptyBorder(1, 1, 1, 1));
        jButton5.setCursor(new java.awt.Cursor(java.awt.Cursor.HAND_CURSOR));
        jButton5.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton5ActionPerformed(evt);
            }
        });

        jButton4.setBackground(new java.awt.Color(204, 51, 0));
        jButton4.setFont(new java.awt.Font("Arial Black", 1, 11)); // NOI18N
        jButton4.setForeground(new java.awt.Color(254, 254, 254));
        jButton4.setText("X");
        jButton4.setBorder(javax.swing.BorderFactory.createEmptyBorder(1, 1, 1, 1));
        jButton4.setCursor(new java.awt.Cursor(java.awt.Cursor.HAND_CURSOR));
        jButton4.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton4ActionPerformed(evt);
            }
        });

        jButton7.setBackground(new java.awt.Color(255, 255, 255));
        jButton7.setFont(new java.awt.Font("Arial Black", 1, 11)); // NOI18N
        jButton7.setForeground(new java.awt.Color(102, 102, 0));
        jButton7.setText("<");
        jButton7.setBorder(javax.swing.BorderFactory.createEmptyBorder(1, 1, 1, 1));
        jButton7.setCursor(new java.awt.Cursor(java.awt.Cursor.HAND_CURSOR));
        jButton7.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton7ActionPerformed(evt);
            }
        });

        javax.swing.GroupLayout jPanel2Layout = new javax.swing.GroupLayout(jPanel2);
        jPanel2.setLayout(jPanel2Layout);
        jPanel2Layout.setHorizontalGroup(
            jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel2Layout.createSequentialGroup()
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addComponent(jLabel15)
                .addGap(168, 168, 168)
                .addComponent(jButton7, javax.swing.GroupLayout.PREFERRED_SIZE, 33, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(jButton5, javax.swing.GroupLayout.PREFERRED_SIZE, 33, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(jButton4, javax.swing.GroupLayout.PREFERRED_SIZE, 33, javax.swing.GroupLayout.PREFERRED_SIZE))
        );
        jPanel2Layout.setVerticalGroup(
            jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                .addComponent(jButton5, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addComponent(jButton7, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addComponent(jButton4))
            .addGroup(jPanel2Layout.createSequentialGroup()
                .addContainerGap()
                .addComponent(jLabel15)
                .addContainerGap(12, Short.MAX_VALUE))
        );

        javax.swing.GroupLayout jPanel1Layout = new javax.swing.GroupLayout(jPanel1);
        jPanel1.setLayout(jPanel1Layout);
        jPanel1Layout.setHorizontalGroup(
            jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(jPanel2, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
            .addComponent(jTabbedPane1, javax.swing.GroupLayout.Alignment.TRAILING)
        );
        jPanel1Layout.setVerticalGroup(
            jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel1Layout.createSequentialGroup()
                .addComponent(jPanel2, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(jTabbedPane1, javax.swing.GroupLayout.PREFERRED_SIZE, 376, Short.MAX_VALUE))
        );

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(jPanel1, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(jPanel1, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
        );

        pack();
    }// </editor-fold>//GEN-END:initComponents

    private void jButton7ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton7ActionPerformed
        // TODO add your handling code here:
        new MenuUtama().show();
        this.dispose();
    }//GEN-LAST:event_jButton7ActionPerformed

    private void jButton5ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton5ActionPerformed
        // TODO add your handling code here:
        setState(ICONIFIED);
    }//GEN-LAST:event_jButton5ActionPerformed

    private void jButton4ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton4ActionPerformed
        // TODO add your handling code here:
        System.exit(0);
    }//GEN-LAST:event_jButton4ActionPerformed

    private void Laporan6ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_Laporan6ActionPerformed
        // TODO add your handling code here:
        barang1 brg = new barang1();
        brg.mb = this;
        brg.setVisible(true);
        brg.setResizable(false);
    }//GEN-LAST:event_Laporan6ActionPerformed

    private void tbjumlMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_tbjumlMouseClicked
        // TODO add your handling code here:
        memilihdata1();
        simpanbj.setEnabled(false);
        Laporan3.setEnabled(true);
    }//GEN-LAST:event_tbjumlMouseClicked

    private void Laporan1ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_Laporan1ActionPerformed
        // TODO add your handling code here:
        Laporan3.setEnabled(false);
        simpanbj.setEnabled(true);
        kosongka2();
        autokode3();
        tglhari();
    }//GEN-LAST:event_Laporan1ActionPerformed

    private void Laporan3ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_Laporan3ActionPerformed
        // TODO add your handling code here:
        updatedata2();
        kosongka2();
        tampiltabel2();
    }//GEN-LAST:event_Laporan3ActionPerformed

    private void idbrActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_idbrActionPerformed
        // TODO add your handling code here:
        hrg .requestFocus();
    }//GEN-LAST:event_idbrActionPerformed

    private void idbjActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_idbjActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_idbjActionPerformed

    private void simpanbjActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_simpanbjActionPerformed
        // TODO add your handling code here:
        simpanjmlah();
    }//GEN-LAST:event_simpanbjActionPerformed

    private void jmlKeyTyped(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_jmlKeyTyped
        // TODO add your handling code here:
        huruf(evt);
    }//GEN-LAST:event_jmlKeyTyped

    private void jmlActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jmlActionPerformed
        // TODO add your handling code here:
        uk.requestFocus();
    }//GEN-LAST:event_jmlActionPerformed

    private void hrgKeyTyped(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_hrgKeyTyped
        // TODO add your handling code here:
        huruf(evt);
    }//GEN-LAST:event_hrgKeyTyped

    private void hrgActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_hrgActionPerformed
        // TODO add your handling code here:
        jml.requestFocus();
    }//GEN-LAST:event_hrgActionPerformed

    private void simpanActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_simpanActionPerformed
        // TODO add your handling code here:
        simpanT();
    }//GEN-LAST:event_simpanActionPerformed

    private void jTable3MouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_jTable3MouseClicked
        // TODO add your handling code here:
        memilihdata();
        simpan.setEnabled(false);
        EDIT.setEnabled(true);
    }//GEN-LAST:event_jTable3MouseClicked

    private void Laporan5ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_Laporan5ActionPerformed
        // TODO add your handling code here:
        kosongkan();
        autokode2();
        tabeltampil();
        EDIT.setEnabled(false);
        simpan.setEnabled(true);
    }//GEN-LAST:event_Laporan5ActionPerformed

    private void EDITActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_EDITActionPerformed
        // TODO add your handling code here:
        updatedata();
    }//GEN-LAST:event_EDITActionPerformed

    private void id_brgActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_id_brgActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_id_brgActionPerformed

    private void namaActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_namaActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_namaActionPerformed

    private void nm_brandActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_nm_brandActionPerformed
        // TODO add your handling code here:
        tglhari();
        nama.requestFocus();
    }//GEN-LAST:event_nm_brandActionPerformed

    private void tglActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_tglActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_tglActionPerformed

    private void tglKeyTyped(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_tglKeyTyped
        // TODO add your handling code here:
    }//GEN-LAST:event_tglKeyTyped

    private void caridata1KeyReleased(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_caridata1KeyReleased
        // TODO add your handling code here:
        String sqlfind = "select * from barang1 where brand like '"+caridata1.getText()+"%' or nama like '"+caridata1.getText()+"%'";
        caridata(sqlfind);
    }//GEN-LAST:event_caridata1KeyReleased

    private void caridt2KeyReleased(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_caridt2KeyReleased
        // TODO add your handling code here:
        String sqlcari = "SELECT idb2,idb,brand,nama,ukuran,jumlah,harga,tanggal\n" +
                     "FROM barang1, barang2\n" +
                     "WHERE barang1.`idb`=`barang2`.`idb1` and brand like '"+caridt2.getText()+"%'"
                    +"OR barang1.`idb`=`barang2`.`idb1` and nama like '"+caridt2.getText()+"%'"
                    +"OR barang1.`idb`=`barang2`.`idb1` and tanggal like '"+caridt2.getText()+"%'";
        caridata2(sqlcari);
    }//GEN-LAST:event_caridt2KeyReleased

    /**
     * @param args the command line arguments
     */
    public static void main(String args[]) {
        /* Set the Nimbus look and feel */
        //<editor-fold defaultstate="collapsed" desc=" Look and feel setting code (optional) ">
        /* If Nimbus (introduced in Java SE 6) is not available, stay with the default look and feel.
         * For details see http://download.oracle.com/javase/tutorial/uiswing/lookandfeel/plaf.html 
         */
        try {
            for (javax.swing.UIManager.LookAndFeelInfo info : javax.swing.UIManager.getInstalledLookAndFeels()) {
                if ("Nimbus".equals(info.getName())) {
                    javax.swing.UIManager.setLookAndFeel(info.getClassName());
                    break;
                }
            }
        } catch (ClassNotFoundException ex) {
            java.util.logging.Logger.getLogger(masterdatabarang.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (InstantiationException ex) {
            java.util.logging.Logger.getLogger(masterdatabarang.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (IllegalAccessException ex) {
            java.util.logging.Logger.getLogger(masterdatabarang.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (javax.swing.UnsupportedLookAndFeelException ex) {
            java.util.logging.Logger.getLogger(masterdatabarang.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        }
        //</editor-fold>

        /* Create and display the form */
        java.awt.EventQueue.invokeLater(new Runnable() {
            public void run() {
                new masterdatabarang().setVisible(true);
            }
        });
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JButton EDIT;
    private javax.swing.JButton Laporan1;
    private javax.swing.JButton Laporan3;
    private javax.swing.JButton Laporan5;
    private javax.swing.JButton Laporan6;
    private javax.swing.JTextField caridata1;
    private javax.swing.JTextField caridt2;
    private javax.swing.JTextField hrg;
    private javax.swing.JTextField id_brg;
    private javax.swing.JTextField idbj;
    private javax.swing.JTextField idbr;
    private javax.swing.JButton jButton4;
    private javax.swing.JButton jButton5;
    private javax.swing.JButton jButton7;
    private javax.swing.JLabel jLabel1;
    private javax.swing.JLabel jLabel10;
    private javax.swing.JLabel jLabel15;
    private javax.swing.JLabel jLabel16;
    private javax.swing.JLabel jLabel17;
    private javax.swing.JLabel jLabel18;
    private javax.swing.JLabel jLabel19;
    private javax.swing.JLabel jLabel2;
    private javax.swing.JLabel jLabel20;
    private javax.swing.JLabel jLabel21;
    private javax.swing.JLabel jLabel22;
    private javax.swing.JLabel jLabel23;
    private javax.swing.JLabel jLabel24;
    private javax.swing.JLabel jLabel25;
    private javax.swing.JLabel jLabel26;
    private javax.swing.JLabel jLabel27;
    private javax.swing.JLabel jLabel28;
    private javax.swing.JLabel jLabel29;
    private javax.swing.JLabel jLabel30;
    private javax.swing.JLabel jLabel31;
    private javax.swing.JLabel jLabel36;
    private javax.swing.JLabel jLabel37;
    private javax.swing.JLabel jLabel7;
    private javax.swing.JPanel jPanel1;
    private javax.swing.JPanel jPanel10;
    private javax.swing.JPanel jPanel2;
    private javax.swing.JPanel jPanel3;
    private javax.swing.JPanel jPanel4;
    private javax.swing.JPanel jPanel5;
    private javax.swing.JPanel jPanel6;
    private javax.swing.JPanel jPanel7;
    private javax.swing.JPanel jPanel9;
    private javax.swing.JScrollPane jScrollPane2;
    private javax.swing.JScrollPane jScrollPane3;
    private javax.swing.JTabbedPane jTabbedPane1;
    private javax.swing.JTable jTable3;
    private javax.swing.JTextField jml;
    private javax.swing.JTextField nama;
    private javax.swing.JTextField nm_brand;
    private javax.swing.JComboBox opsi;
    private javax.swing.JButton simpan;
    private javax.swing.JButton simpanbj;
    private javax.swing.JTable tbjuml;
    private javax.swing.JTextField tgl;
    private javax.swing.JComboBox uk;
    // End of variables declaration//GEN-END:variables

    private boolean jTable3MouseClicked() {
        throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
    }
}
